library("WGCNA")

a=which(as.matrix(str[1,])=="Primary"&as.matrix(str[1,])!="gleason_NA")
#b=which(as.matrix(str[1,])=="Metastasis")

prna=rna[,a]
pmir=mir[,a]
pstr=str[,a]
mir_id=mir[,1]
rna_id=rna[,1]

col=rep("red",98)
g8_9=which(as.matrix(pstr[2,])=="gleason_8"|as.matrix(pstr[2,])=="gleason_9")
col[g8_9]="blue"

g7=which(as.matrix(pstr[2,])=="gleason_7")
#col[g7]="green"

m5n=read.table("result_primary/modu-5-ne.txt",header=F, sep="\t")
s1=names(table(m5n[,1]))
s2=names(table(m5n[,2]))

#par(mfrow=c(2,1),mar=c(1,4,1.5,1))
#m=match(mir_id,s1,nomatch=0)
#ix=which(m!=0)
#hc2=hclust(dist(t(pmir[ix,])), method="ward")

m=match(rna_id,s2,nomatch=0)
ix=which(m!=0)
hc2=hclust(dist(t(prna[ix,])), method="ward")

ob2=plotDendroAndColors(hc2, colors=col, dendroLabels=F, hang=-1, autoColorHeight=F, colorHeight=.1, groupLabels="", main="B")
c2=cutree(hc2,k=2)

##############
#p=rep(0,1000)
#for(i in 1:1000){
#gn=dim(rna)[1]
#ix=sample(1:gn,40, replace=F)

s=read.table("result_primary/mutated_gene_cancer_cell.txt",header=F, sep="\t")
m=match(rna_id,s[,1], nomatch=0)
ix=which(m!=0)
hc1=hclust(dist(t(prna[ix,])), method="ward")
#ob1=plotDendroAndColors(hc1, colors=col, dendroLabels=F, hang=-1, autoColorHeight=F, colorHeight=.1, groupLabels="", main="B")
c1=cutree(hc1,k=3)

ot=chisq.test(as.factor(c2),as.factor(as.matrix(c1)))
p=ot$p.value

print(p)


#}






