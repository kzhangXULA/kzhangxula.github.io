f=read.table("fileList.txt", header=F, sep="\t")

term="symbol"

for(i in 1:dim(f)[1]){
  name=as.character(f[i,1])
  dat=read.csv(name, header=T, sep="\t")
  ix=which(dat$Benjamini<0.05)

  if(length(ix)>=1){
    #dat$Benjamini=formatC(dat$Benjamini, digits=2)
    name=paste("filted/",name, sep="")
    write.table(dat[ix,c(1,2,3,12)], file=name, col.names=T, row.names=F, sep="\t", quot=F)
    term=c(term, as.character(dat[ix,2]))
  }

}

l=length(term)
term=names(table(as.character(term)))
l=length(term)
term=as.data.frame(term)


####################
f=read.table("filted/fileList.txt", header=F, sep="\t")
for(i in 1:dim(f)[1]){
  #temp=rep(1,l)
  temp=rep(1000,l)
  name=as.character(f[i,1])
  name=paste("filted/",name,sep="")
  dat=read.csv(name, header=T, sep="\t")

  m=match(term[,1],dat[,2],nomatch=0)
  a=which(m!=0)
  b=m[a]
  temp[a]=dat[b,4]
  #temp[a]=formatC(dat[b,4], digits=2)

  temp=as.data.frame(temp)
  names(temp)=substr(name,8,18)
  term=cbind(term,temp)
}

write.table(term, file="filted/summary.txt", col.names=T, row.names=F, sep="\t", quote=F)
ix=which(substr(as.character(term[,1]),1,3)=="hsa")

#n=dim(term)[1];ix=1:n

term=term[,c(1:9,19:24)]

m=dim(term)[2]
kegg=data.frame(term[ix,2:m],row.names=term[ix,1])
x1=names(kegg)
kegg=pmin(-log10(as.matrix(kegg)),4)

ia=colMeans(kegg)
ib=which(ia!=0)
kegg=kegg[,ib]
x1=x1[ib]

ob=heatmap.2(as.matrix(kegg),dendrogram="none", trace="none")
ix=ob$colInd
iy=ob$rowInd

#labs=c("0.0","0.5","1.0","1.5","2.0","2.5","3.0","3.5",">=4.0")

map=levelplot(t(kegg[iy,ix]),cex=.5,scales=list(x=list(labels=x1[ix],rot=90),cex=.7), xlab=NULL, ylab=NULL, col.regions=heat.colors)

print(map)
















  
  
  

