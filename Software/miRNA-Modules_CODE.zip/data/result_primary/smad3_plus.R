ip=which(str[1,]=="Primary")
im=which(str[1,]=="Metastasis")
#in=which(str[1,]=="normal")

m5n=read.table("result_primary/modu-5-ne.txt",header=F, sep="\t")
mi=names(table(m5n[,1]))

m=match(mir[,1],mi, nomatch=0)
a=which(m!=0)

#b=which(rna[,1]==gene)
gene=read.table("result_primary/beta_downstream.txt",header=F, sep="\t")
m=match(rna[,1],gene[,1], nomatch=0)
b=which(m!=0)

v1=mir[a,ip]
v2=rna[b,ip]

r=cor(as.matrix(t(v1)),as.matrix(t(v2)))
p.value=pt(-abs(r)*sqrt((98-2)/(1-r^2)),96)

r=round(r,3)
p=formatC(p.value, format="e", digits=1)

#out=data.frame(cbind(as.vector(mir[a,1]), r, p.value))
#names(out)=c("miR","cor","p.value")
#print(out)


main="Correlaton between miRNAs and mRNA intensities"     
labCol=as.vector(as.vector(rna[b,1]))
labRow=as.vector(as.vector(mir[a,1]))
heatmap.2(r, dendrogram="both", trace="none", cellnote=p, labCol=labCol, labRow=labRow, cexCol=.8, cexRow=.8, notecex=.8)






