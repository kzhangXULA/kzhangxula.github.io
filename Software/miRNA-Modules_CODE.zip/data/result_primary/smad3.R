ip=which(str[1,]=="Primary")
im=which(str[1,]=="Metastasis")
#in=which(str[1,]=="normal")

m5n=read.table("result_primary/modu-5-ne.txt",header=F, sep="\t")
mi=names(table(m5n[,1]))

m=match(mir[,1],mi, nomatch=0)
a=which(m!=0)

#b=which(rna[,1]=="NMI")
b=which(rna[,1]==gene)

v1=mir[a,ip]
v2=rna[b,ip]

r=cor(as.matrix(t(v1)),as.matrix(t(v2)))
p.value=pt(-abs(r)*sqrt((98-2)/(1-r^2)),96)

r=round(r,3)
p.value=formatC(p.value, format="e", digits=2)

out=data.frame(cbind(as.vector(mir[a,1]), r, p.value))
names(out)=c("miR","cor","p.value")

print(out)



