library("WGCNA")

a=which(as.matrix(str[1,])=="Primary"&as.matrix(str[1,])!="gleason_NA")
#b=which(as.matrix(str[1,])=="Metastasis")

prna=rna[,a]
pmir=mir[,a]
pstr=str[,a]
mir_id=mir[,1]
rna_id=rna[,1]

col=rep("red",98)
g8_9=which(as.matrix(pstr[2,])=="gleason_8"|as.matrix(pstr[2,])=="gleason_9")
col[g8_9]="blue"

g7=which(as.matrix(pstr[2,])=="gleason_7")
#col[g7]="green"

s=read.table("result_primary/mutated_gene_cancer_cell.txt",header=F, sep="\t")

m=match(rna_id,s[,1], nomatch=0)
ix=which(m!=0)
hc1=hclust(dist(t(prna[ix,])), method="ward")
ob=plotDendroAndColors(hc1, colors=col, dendroLabels=F, hang=-1, autoColorHeight=F, colorHeight=.1, groupLabels="", main="B")

