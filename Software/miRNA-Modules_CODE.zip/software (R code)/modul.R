### Identifying miRNA:mRNA correlation modules.
### Prompted by cluster_2.R

summ=function(class,x1,x2,x3,modu,cln,rna_s,mir,tf,hsa,tg){
  fdir=paste("result_",class,sep="")
  dir.create(fdir)

  for(i in 1:cln){
    a1=which(modu[,1]==i)
    a2=modu[a1,2]
    a3=match(mir[,1],a2,nomatch=0)
    a4=which(a3!=0)
    a5=mir[a4,1]

    b1=which(rowSums(x1[,a4]+x2[,a4])>1)
    b2=rna_s[b1,1]

    m=length(a5)
    n=length(b2)

    c1=rep(1:m,n)
    c1=sort(c1)
    c1=a5[c1]                                           #miRNA

    c2=rep(b2,m)                                        #rna

    x=x2-x1
    c3=as.vector(x[b1,a4])                              #correlation
    
    ix=which(c3!=0)                                     #refining
    c1=c1[ix]
    c2=c2[ix]
    c3=c3[ix]

    c4=rep(0,length(c3))
    t1=match(c2,tf,nomatch=0)                           #TF
    t2=which(t1!=0)
    c4[t2]=1

    tn=length(c1)
    c5=rep(0,tn)                                        #sequence affinity
    for(j in 1:tn){
      ix1=which(hsa[,4]==as.character(c1[j]))
      id1=hsa[ix1,1]                                   
      id2=c2[j]
      ix2=which(tg[,1]==as.character(id1)&tg[,3]==as.character(id2))
      if(length(ix2)>0)c5[j]=1
    }
 
    c1=as.character(c1)
    c2=as.character(c2)
    c3=as.character(c3)
    c4=as.character(c4)
    c5=as.character(c5)
    out=as.data.frame(cbind(c1,c2,c3,c4,c5))

    c6=rep(0,tn)                                       #targetScan affinity
    id=paste(c1,c2,sep="_")
    m=match(id,tg_TS,nomatch=0)
    ix=which(m!=0)
    c6[ix]=1
    out=cbind(out,c6)    


    fname1=paste(fdir,"/","modu-",i,"-ps",".txt",sep="")
    fname2=paste(fdir,"/","modu-",i,"-ne",".txt",sep="")

    #s=which(out[,3]==1|c4==1)
    s=which(out[,3]==1)
    write.table(out[s,], file=fname1, col.names=F, row.names=F, sep="\t", quote=F)

    #s=which(out[,3]==-1|c4==1)
    s=which(out[,3]==-1)
    write.table(out[s,], file=fname2, col.names=F, row.names=F, sep="\t", quote=F)
   
  }
  
}

        
   

     
    



