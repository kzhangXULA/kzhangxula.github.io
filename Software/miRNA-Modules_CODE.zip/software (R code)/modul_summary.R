### Summarizing module information

unlink("modu_summary")
dir.create("modu_summary")

f=read.table(file="moduList.txt", header=F, sep="\t")
n=dim(f)[1]

head=c("modul", "gene_number","TF_number", "miRNA", "TF")
write.table(t(head), "modu_summary/output.txt", col.names=F, row.names=F, sep="\t", quote=F)


for(i in 1:n){
  name=as.character(f[i,1])
  dat=read.table(name, header=F, sep="\t")

  l=nchar(name)
  modul=substr(name,8,l-4)
  gene_number=length(names(table(dat[,2])))
 
  miRNA=names(table(dat[,1]))
  miRNA=paste(miRNA,collapse=", ")

  ix=which(dat[,4]==1)
  TF=dat[ix,2]
  TF=names(table(as.character(TF)))
  TF_number=length(TF)
  TF=paste(TF,collapse=", ")

  out=c(modul,gene_number,TF_number,miRNA,TF)
  write.table(t(out), "modu_summary/output.txt", col.names=F, row.names=F, sep="\t", quote=F, appen=T)  
   
}  



