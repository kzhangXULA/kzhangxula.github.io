### Target site enrichment test for miRNA:mRNA module genes

hsa=read.table("miR_Family_Info.txt", header=T, sep="\t"); hsa=hsa[,c(1,4)]
tg=read.table("condensed_target_ref_1.txt", header=T, sep="\t"); tg=tg[,1:3]
gn=length(names(table(tg[,3])))


m4n=read.table("result_normal/modu-5-ps.txt",header=F, sep="\t")
main="n-modu-5-ps"

mi=names(table(m4n[,1]))
m=length(mi)
ratio=matrix(0,m,2)
p=rep(0,m)

for(i in 1:m){
  a=which(m4n[,1]==mi[i])
  ratio[i,1]=round(sum(m4n[a,5])/length(a),4)

  b=which(hsa[,2]==mi[i])
  c=hsa[b,1]

  d=length(which(tg[,1]==c))
  ratio[i,2]=round(d/gn,4)

  tp=sum(m4n[a,5])
  np=length(a)-tp
  tf=gn-d
  nf=d-tp-np

  tab=matrix(c(tp,np,nf,tf),nrow=2)
  p[i]=fisher.test(tab, alternative = "two.sided")$p.value

}

p=formatC(p, format = "e", digits = 2)
lab=paste("p",p,sep=" = ")

ratio=data.frame(ratio,row.names=mi)
names(ratio)=c("Module genes", "Whole set of genes")
ylab="Percentage of genes with 7-mer or 8-mer target site (%)" 

mp=barplot(t(ratio)*100, beside=T, ylim=c(0,40), legend=names(ratio),
        args.legend = list(x = "top",ncol=2,bty="n"), ylab=ylab, main=main)

mtext(side = 1, at = colMeans(mp), line = -4, text = lab, col = "red", cex=0.8)



