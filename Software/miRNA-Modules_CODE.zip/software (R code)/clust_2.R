### A pipline for data precessing, correlation computation, SVD analysis and clustering analysis


 bcor=function(mt1, mt2, set){
   n1=dim(mt1)[1]
   n2=dim(mt2)[1]
   m=dim(mt1)[2]
   r=matrix(0,n1,n2)

   for(i in 1:1000){
     ix=sample(1:m,s,replace=F)
     r=r+cor(t(mt1[,ix]),t(mt2[,ix]))
   }

   r=r/1000
   list(OT=r)
 }  


 #################
 dist1=function(mt){
   n=dim(mt)[1]
   ov=matrix(0,n,s)

   for(i in 1:n){
     for(j in 1:n){
       a=which(mt[i,]==1&mt[j,]==1)
       b=which(mt[i,]==1|mt[j,]==1)
       a=length(a);b=length(b)
       if(b!=0)ov[i,j]=round(a/b,6)
     }
   }

   list(OT=ov)
 }     
###################


 hsa=read.table("miR_Family_Info.txt", header=T, sep="\t")
 tg=read.table("condensed_target_ref_1.txt", header=T, sep="\t")
 tg=tg[,1:3]


 mir=read.table("miRNA.txt", header=T, sep="\t")
 rna=read.table("geneExp.txt", header=T, sep="\t")
 canc=read.table("cancer_miRNA.txt", head=T, sep="\t")
 str=read.table("str.txt", header=T, sep="\t")

 onc=canc[which(canc[,2]=="ONCO"),]
 sup=canc[which(canc[,2]=="SUPP"),]

 q=dim(mir)[2];p=dim(mir)[1]
 dif=apply(rna[,2:q],1,max)-apply(rna[,2:q],1,min)
 s=which(dif>=2)
 length(s)
 rna=rna[s,] 
 
 ia=which(str[1,]=="Primary")
 id=ia
 r=bcor(rna[,id],mir[,id],10)$OT
 rR=r;nR=10

 id=which(str[1,]=="Primary")
 r=bcor(rna[,id],mir[,id],78)$OT
 rP=r;nP=78

 id=which(str[1,]=="Metastasis")
 r=bcor(rna[,id],mir[,id],10)$OT
 rM=r;nM=10

 id=which(str[1,]=="normal")
 r=bcor(rna[,id],mir[,id],22)$OT
 rN=r;nN=22

 r=bcor(rna[,2:q],mir[,2:q],111)$OT
 rW=r;nW=111
 
 x=data.frame(rM,row.names=rna[,1])
 names(x)=mir[,1]
 #write.table(x, file="correlation_matrix/metastasis.txt",row.names=T, col.names=T, sep="\t", quote=F)
 #rM=read.table("correlation_matrix/metastasis.txt", header=T, sep="\t");rM=as.matrix(rM)


 x=data.frame(rN,row.names=rna[,1])
 names(x)=mir[,1]
 #write.table(x, file="correlation_matrix/normal.txt",row.names=T, col.names=T, sep="\t", quote=F)
 #rN=read.table("correlation_matrix/normal.txt", header=T, sep="\t");rN=as.matrix(rN)

 x=data.frame(rP,row.names=rna[,1])
 names(x)=mir[,1]
 #write.table(x, file="correlation_matrix/primary.txt",row.names=T, col.names=T,sep="\t", quote=F)
 #rP=read.table("correlation_matrix/primary.txt", header=T, sep="\t");rP=as.matrix(rP)

 x=data.frame(rW,row.names=rna[,1])
 names(x)=mir[,1]
 #write.table(x, file="correlation_matrix/whole_sample.txt",row.names=T, col.names=T, sep="\t", quote=F)
 #rW=read.table("correlation_matrix/whole_sample.txt", header=T, sep="\t");rW=as.matrix(rW)



#########

 library(limma)

 c=dim(rM)[2];r=dim(rM)[1]
 pM=pt(-abs(rM)*sqrt((13-2)/(1-rM^2)),11);pM=p.adjust(pM,method="BH")
 pN=pt(-abs(rN)*sqrt((28-2)/(1-rN^2)),26);pN=p.adjust(pN,method="BH")
 pP=pt(-abs(rP)*sqrt((98-2)/(1-rP^2)),96);pP=p.adjust(pP,method="BH")
 pW=pt(-abs(rW)*sqrt((139-2)/(1-rW^2)),137);pW=p.adjust(pW,method="BH")

 rM1=rM2=rN1=rN2=rP1=rP2=rW1=rW2=rep(0,c*r)
 x=as.vector(pM);y=as.vector(rM);d1=which(x<0.05&y<0);d2=which(x<0.05&y>0);rM1[d1]=1;rM2[d2]=1
 x=as.vector(pN);y=as.vector(rN);d1=which(x<0.05&y<0);d2=which(x<0.05&y>0);rN1[d1]=1;rN2[d2]=1
 x=as.vector(pP);y=as.vector(rP);d1=which(x<0.05&y<0);d2=which(x<0.05&y>0);rP1[d1]=1;rP2[d2]=1
 x=as.vector(pW);y=as.vector(rW);d1=which(x<0.05&y<0);d2=which(x<0.05&y>0);rW1[d1]=1;rW2[d2]=1

 rM1=matrix(rM1,r,c);rM2=matrix(rM2,r,c)
 rN1=matrix(rN1,r,c);rN2=matrix(rN2,r,c)
 rP1=matrix(rP1,r,c);rP2=matrix(rP2,r,c)
 rW1=matrix(rW1,r,c);rW2=matrix(rW2,r,c)


####

 sanger=read.table("Sanger_2010-12-01_edit.txt", header=T, sep="\t")
 isup=which(sanger[,2]=="Rec")
 gsup=sanger[isup,]
 mc=match(rna[,1],gsup[,1], nomatch=0)
 msup=which(mc!=0)

 sanger=read.table("Sanger_2010-12-01_edit.txt", header=T, sep="\t")
 ionc=which(sanger[,2]=="Dom")
 gonc=sanger[ionc,]
 mc=match(rna[,1],gonc[,1], nomatch=0)
 monc=which(mc!=0)

 cpath=read.table("cancer_Prostate.txt", header=T, sep="\t")
 mcpath=match(rna[,1],cpath[,1],nomatch=0)
 icpath=which(mcpath!=0)

 cpath=read.table("goa_human.txt", header=T, sep="\t")
 #ia=which(cpath[,2]=="GO:0007049")
 ia=which(cpath[,2]=="GO:0003700"|cpath[,2]=="GO:0003702"|cpath[,2]=="GO:0003709"|cpath[,2]=="GO:0016563"|cpath[,2]=="GO:0016564")
 cpath=cpath[ia,]
 mcpath=match(rna[,1],cpath[,1],nomatch=0)
 icpath=which(mcpath!=0)
 tf=rna[icpath,1]

 #icpath=1:5726
 #icpath=msup

 a=match(mir[,1],sup[,1])
 p=which(a!=0)

 b=match(mir[,1],onc[,1])
 q=which(b!=0)

 
 x1=rN1[,c(p,q)];x2=rN2[,c(p,q)]
 top=which(rowSums(x1)-rowSums(x2)>1)
 
 library(gplots)
 m.hclust <- function(d) hclust(d, method="ward")
 my.dist <- function(x) dist(x, method="manhattan")
 my.hclust=heatmap.2(x1[top,]-x2[top,],distfun=my.dist,hclust=m.hclust,col=heat.colors(3),labCol=mir[c(p,q),1],labRow=F,cexCol=.5,
                     dendrogram="column", trace="none", key="none")
 
 ix=my.hclust$colInd
 ls=mir[c(p,q),1]
 id=ls[ix]
 
 cl=rep(0, length(c(p,q)))
 
 #cl[1:5]=1;cl[6:14]=2;cl[15:18]=3;cl[19:20]=4;cl[35:41]=5;cl[42:46]=6;cl[47:51]=7;cl[52:58]=8;cln=8;class="primary"
 #cl[2:4]=1;cl[46:48]=2;cl[49:54]=3;cl[55:58]=4;cln=4;class="metastasis"
 cl[2:4]=1;cl[53:54]=2;cl[55:58]=3;cln=3;class="normal"

 modu=as.data.frame(cbind(cl,as.character(id)))
 
 source("modul.R")
 #summ(class,rN1[top,],rN2[top,],rN[top,],modu,cln,rna[top,],mir,tf,hsa,tg)








