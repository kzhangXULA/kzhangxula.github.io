Copyright: Wensheng Zhang and Kun Zhang
If you use the code in this package,
Please cite: miRNA-mRNA Correlation-Network Modules in Human Prostate Cancer and the Differences between Primary and Metastatic Tumor Subtypes. PLoS ONE 7(6): e40130. doi:10.1371/journal.pone.0040130
