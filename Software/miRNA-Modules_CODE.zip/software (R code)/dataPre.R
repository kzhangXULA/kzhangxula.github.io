## Adapt gene expression data from refSeq gene IDs to official gene symbols


dat=read.csv("mRNA.txt", header=T, sep="\t")
ref=read.table("refFlat.txt", header=T, sep="\t")
q=dim(dat)[2]
gene=names(table(ref[,1]))

m=match(ref[,2],dat[,1],nomatch=0)
ix=which(m!=0)
out=cbind(ref[ix,1],dat[m[ix],2:q])

write.table(t(names(dat)),file="geneExp.txt", col.names=F, row.names=F, sep="\t", quote=F)
for(i in 1:length(gene)){
  ix=which(out[,1]==gene[i])
  set=out[ix,2:q]
  av=colMeans(set)
  av=round(log2(av),3)
  if(length(ix)>0)write.table(t(c(gene[i],av)),file="geneExp.txt", col.names=F, row.names=F, sep="\t", quote=F, appen=T)
}
