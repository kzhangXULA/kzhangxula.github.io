function [answ] = LogitObj(y,X,beta)
answ=-(y'*X*beta-sum(log(1+exp(X*beta))));
end

