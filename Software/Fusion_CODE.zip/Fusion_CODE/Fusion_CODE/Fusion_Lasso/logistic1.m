
function [ahat,finbhat,run] = logistic1(X,y,lambda,opt,a,cont,w1,w2,varargin)

n=size(X,1); 
lam=fliplr(lambda);  

thr = 1e-6; maxit = 1000;
Xt=[ones(n,1),X];
p=size(Xt,2);

ahat = zeros(length(lam),1); bhat=zeros(p,1); finbhat=zeros(p-1,length(lam));
step = .1;

if nargin < 9

else
    w2=abs(varargin{1});
end

switch opt
    case 'lasso'
        k=cont;
        m=size(X,2)-k; 
        dim=[k m];
      for i=1:length(lam)
        ind = 1; iter = 1;  
        lam1=repmat(lam(i),dim(1),1).*w1';
        lam2=repmat(lam(i),dim(2),1).*w2';
        pen = [lam1' lam2']';
          while thr<ind && iter<maxit
              oldb = bhat; t = 1;
              grad = grad_LogitObj(y,Xt,oldb)/n; 
              oldobj = LogitObj(y,Xt,oldb)/n; 
              tmp = oldb - t*grad;
              bhat(1) = tmp(1); 
              bhat(2:end) = sign(tmp(2:end)).*max(abs(tmp(2:end)) - pen*t,0);
              newobj = LogitObj(y,Xt,bhat)/n;

          while newobj > oldobj - grad'*(oldb - bhat) + t/2*norm(1/t*(oldb-bhat),2)^2

              t = t*step;
              tmp = oldb - t*grad;
              bhat(1) = tmp(1); 
              bhat(2:end) = sign(tmp(2:end)).*max(abs(tmp(2:end)) - pen*t,0);
              newobj = LogitObj(y,Xt,bhat)/n;
          end

          iter = iter + 1;
          ind = sum((oldb - bhat).^2);

         end
        run(i)=iter;  
        ahat(i) = bhat(1);
        finbhat(:,i) = bhat(2:end);

      end
      case 'SepPenalty'
         k=cont;
         m=size(X,2)-k;
         dim=[k m];
         for i=1:length(lam)
            lam1=repmat(lam(i),dim(1),1)*a;
            lam2=repmat(lam(i),dim(2),1)*(1-a);
            pen = [lam1' lam2']';
            ind = 1; iter = 1;
            
          while thr<ind && iter<maxit
              oldb = bhat; t = 1;
              grad = grad_LogitObj(y,Xt,oldb); 
              oldobj = LogitObj(y,Xt,oldb); 
              tmp = oldb - t*grad;
              bhat(1) = tmp(1); 
              bhat(2:end) = sign(tmp(2:end)).*max(abs(tmp(2:end)) - pen*t,0);
              newobj = LogitObj(y,Xt,bhat);

          while newobj > oldobj - grad'*(oldb - bhat) + t/2*norm(1/t*(oldb-bhat),2)^2
              t = t*step;
              tmp = oldb - t*grad;
              bhat(1) = tmp(1); 
              bhat(2:end) = sign(tmp(2:end)).*max(abs(tmp(2:end)) - pen*t,0);
              newobj = LogitObj(y,Xt,bhat);
          end

          iter = iter + 1;
          ind = sum((oldb - bhat).^2);
          end
         
        run(i)=iter;  
        ahat(i) = bhat(1);
        finbhat(:,i) = bhat(2:end);
         end
end
end