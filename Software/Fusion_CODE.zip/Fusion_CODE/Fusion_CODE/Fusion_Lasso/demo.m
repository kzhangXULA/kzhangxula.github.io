n=200;
px=300;
py=300;
pz=300;
p=900;

sigma = 3;

x1=zeros(n,px);
for i=1:px
x1(:,i)=normrnd(0,sigma,[n,1]); 
end


wt2= .5;
x2=zeros(n,px);
for i=1:px
  x2(:,i)= binornd(1,wt2,n,1);
end


alpha = 1;
x3=zeros(n,px);
for i=1:px
  x3(:,i)= poissrnd(alpha,n,1);
end


x=[x1,x2,x3];


nnz_beta=30;
ind1=[1:10,px+1:px+10,px+py+1:px+py+10];
w1=(10-5)*rand(nnz_beta,1) + 5;
pm=rand(nnz_beta,1);
pm(pm<.5)=-1;
pm(pm>=.5)=1;

beta=zeros(p,1);
beta(ind1)=w1.*pm;



temp_var=std(x);
y=x*(beta./temp_var')+normrnd(0,1,[n,1]);

Y=y;
mn=mean(x);
sd=sqrt(var(x));
cntr=bsxfun(@minus,x,mn);
stdX=bsxfun(@rdivide,cntr,sd); 

[b1,b2,b3,str,path] = Fusion(stdX, Y, px,py,0.8,1,0.2,'normal');

find(b1)
find(b2)
find(b3)
