function [maxL] = MaxLambda(x,y,n,px,distr)

switch distr    
  case 'Gaus'  
            for k=1:px-1
                temp(k)=abs(x(:,k)'*(y));    
            end
            maxL=max(temp)/(n);   
    
    
  case 'other'  
            for k=1:px-1
                temp(k)=abs(x(:,k)'*(y-mean(y)));    
            end
            maxL=max(temp)/(n);  
end