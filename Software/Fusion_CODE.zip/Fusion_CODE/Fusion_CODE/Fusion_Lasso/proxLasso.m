
function [finbhat1,finbhat,run] = proxLasso(X,Y,lambda,opt,a,disc,w1,w2,varargin)

[n,p]=size(X);

    L = 1/n*(eigs(X'*X,1));


lam=fliplr(lambda);
finbhat=zeros(size(X,2),length(lam));
run=zeros(length(lam),1);
bhat=zeros(size(X,2),1);

ahat=0;

if nargin < 9

else
    w2=abs(varargin{1});
end

dim=disc;
switch opt
    case 'lasso'
        for i=1:length(lam)

          lam1=repmat(lam(i),dim,1).*w1';
          lam2=repmat(lam(i),p-dim,1).*w2';
          pen = [lam1' lam2']'; 
  
          ind=1;  thr = 1.0e-6; iter = 1;
            while ind>thr && iter<10000
    
                olda=ahat; 
                oldb = bhat; 
                ahat=sum(Y-X*bhat)/n;
                btild = bhat - 1/n*(X'*(X*bhat - Y + ahat)/L);
                bhat = sign(btild).*max(abs(btild) - pen/L,0);
                ahat=sum(Y-X*bhat)/n;               
                old=[olda oldb']';
                new=[ahat bhat']';
                ind = norm(old - new)/norm(old);
                iter = iter + 1;
            end
        ahat=-ahat;
        run(i)=iter;
        finbhat(:,i)=bhat;
       
        end

        finbhat1=bhat;
            
    case 'SepPenalty'
        m=disc;
        k=p-m;
        dim=[k,m];
       for i=1:length(lam)
          lam1=repmat(lam(i),dim(1),1)*a;
          lam2=repmat(lam(i),dim(2),1)*(1-a);
          pen = [lam1' lam2']';
          ind = 1; thr = 1e-6; iter = 1;
        while ind>=thr && iter<1000
            olda=ahat;
            oldb = bhat; 
            btild = bhat - X'*(X*bhat - Y - ahat)/L;
            bhat = sign(btild).*max(abs(btild) - pen/L,0);
            old=[olda oldb']';
            new=[ahat bhat']';
            ind = norm(old - new)/norm(old);
            iter = iter + 1;
            
        end
        run(i)=iter;
        finbhat(:,i)=bhat;
       end
end
end


