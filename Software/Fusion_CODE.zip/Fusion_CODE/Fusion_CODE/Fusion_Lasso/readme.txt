Copyright: Zhong Chen and Kun Zhang
If you use code in this package please cite
Chen, Z., Edwards, A. and Zhang, K., 2020, September. Fusion Lasso and Its Applications to Cancer Subtype and Stage Prediction. In Proceedings of the 11th ACM International Conference on Bioinformatics, Computational Biology and Health Informatics (pp. 1-8).

Required software
Matlab

Run demo.m
