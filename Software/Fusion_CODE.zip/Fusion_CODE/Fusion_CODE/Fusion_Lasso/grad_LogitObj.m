function [grad] = grad_LogitObj(y,X,beta)
grad=-X'*(y - exp(X*beta)./(1+exp(X*beta)));
end

