
function [b1,x1,x1th] = BlockPostProcess(R1Final,tau1,Y_raw,Xblock,Xnon_block,link,x1th) 
 
    th1=1/size(R1Final,2)*(sum(double(abs(R1Final)>0),2));
    x1th=[x1th,th1];
    th1(th1<tau1)=0;
    th1=logical(th1);


    y=Y_raw;
    
    
    
    
    x1=Xblock(:,th1);
    p1=size(Xblock,2);

    if size(x1,2)==0
        b1=zeros(p1,1);
    else


    [temp,~,~]=glmfit([x1,Xnon_block],y,link);
    temp=temp(2:end);
    temp(abs(temp)<0.00001)=0;
    b1temp=zeros(p1,1);           
    temp=temp(1:size(x1,2));
    b1temp(th1)=temp;

    b1=b1temp;

    end