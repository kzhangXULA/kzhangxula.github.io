function [R1] = LassoBlock(Xblock,Xnon_block, Yuse, lam_ind1,bnon_block,temp,resp) 
    
 a=0.8;
 b=1.2;
 R1=zeros(size(Xblock,2),1);

     w=temp;
     w(w~=0)=lam_ind1;
     w(w==0)=lam_ind1*2;

     rx = (b-a).*rand(1,size(Xblock,2)) + a;

     pen1=rx'.*w; 
     pxy=nnz(bnon_block);
     pen1=[pen1;0.1*min(pen1)*ones(pxy,1)];

switch resp
    case 'normal'
        try
        [~,R1,~]=proxLasso([Xblock,Xnon_block(:,bnon_block~=0)],Yuse,1,'lasso',1,0,1,1,pen1'); 
        catch
         disp('Eigenvalue error');   
        end
    case 'binomial'
        [~,R1,~]=logistic1([Xblock,Xnon_block(:,bnon_block~=0)],Yuse,1,'lasso',1,0,1,1,pen1'); 
  
    case 'poisson'
        [~,R1,~]=PoisLoc1([Xblock,Xnon_block(:,bnon_block~=0)],Yuse,1,'lasso',1,0,1,1,pen1'); 
%      m=nnz(R1(1:p1));
    otherwise
        warning('Unexpected response type')
end

end
