

function [alphas,Bmat,run]=PoisLoc1(X,Y,lam,opt,a,dim1,w1,w2,varargin) 
[n,p]=size(X);


lams=fliplr(lam);
nLam=length(lam);

 
  thr = 1e-5; maxit = 1e4;
  Xt=[ones(n,1),X];

  alphas = 0; 
  startb=0;
  Bmat = zeros(p,nLam);
  if sum(startb)==0

      Bhat = zeros(p+1,1); 
      Bhat(1) = 0;
  else Bhat=startb;
  end
  

if nargin < 9

else
    w2=abs(varargin{1});
end

dim=dim1;
  
  switch opt
    case 'lasso'
        for i=1:length(lams)
            iter = 1; ind = 1;
            lam1=repmat(lams(i),dim,1).*w1';
            lam2=repmat(lams(i),p-dim,1).*w2';
            pen = [lam1' lam2']';
        while thr<ind && iter<maxit
          tk =1; 
          bs= 0.5;
          oldb = Bhat; 
          smthgrad = -(1/n)*(Xt'*(Y - exp(Xt*Bhat)));
          tmp = oldb - smthgrad*tk;
          Bhat(1) = tmp(1);              
          Bhat(2:end) = sign(tmp(2:end)).*max(abs(tmp(2:end)) - pen*tk,0);
          smthobj_newb = -(1/n)*(Y'*Xt*Bhat-sum(exp(Xt*Bhat))); 
		  smthobj_oldb = -(1/n)*(Y'*Xt*oldb-sum(exp(Xt*oldb))); 

		  while smthobj_newb > (smthobj_oldb -smthgrad'*(oldb-Bhat)+(1/(2*tk))*sum((oldb-Bhat).^2))
				tk = bs*tk;
				tmp = oldb-tk*smthgrad;
				Bhat(1)=tmp(1);
				Bhat(2:end) = sign(tmp(2:end)).*max(abs(tmp(2:end)) - pen*tk,0);
				smthobj_newb = -(1/n)*(Y'*Xt*Bhat-sum(exp(Xt*Bhat))); %(1/n)*
          end
            
          obj1(:,iter)=smthobj_newb;
          
          ind = norm(oldb - Bhat)/norm(oldb);
          iter = iter + 1;
            
         end
            alphas(i) = Bhat(1);
            Bmat(:,i) = Bhat(2:end,:);
            run(i)=iter;
        end
  
     case 'SepPenalty'
        m=dim1;
        k=p-m;
        dim=[k+1,m];
       for i=1:length(lams)
          lam1=repmat(lams(i),dim(1),1)*a;
          lam2=repmat(lams(i),dim(2),1)*(1-a);
          pen = [lam1' lam2']';
          ind = 1; thr = 1e-6; iter = 1;
        while ind>=thr && iter<10000
          oldb = Bhat;
          tmp = Bhat - Xt'*(Y - exp(-Xt*Bhat))/L;
          Bhat = sign(tmp).*max(tmp - pen/L,0);
          Bhat(1) = tmp(1);
          ind = sum((Bhat - oldb).^2);
          iter = iter + 1;
        end
            alphas(i) = -Bhat(1);
            Bmat(:,i) = -Bhat(2:(p+1),:);
            run(i)=iter;
        end
   end
 end

  
  