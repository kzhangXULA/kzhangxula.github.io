
function [lam_ind,temp1,lambda11] = InitialLambda(X, Y, n,p,prcnt,resp)

mlG1=max(MaxLambda(X,Y,n,size(X,2)+1,'other')); %545.4
lambda11=mlG1*logspace(log10(0.0001),log10(1),100);



switch resp
    case 'normal'
        [~,temp1,~]=proxLasso(X,Y,lambda11,'lasso',1,0,1,1,1); 
    
    case 'binomial'
        [~,temp1,~]=logistic1(X,Y,lambda11,'lasso',1,0,1,1,1); 
  
    case 'poisson'
        [~,temp1,~]=PoisLoc1(X,Y,lambda11,'lasso',1,0,1,1,1); 

    otherwise
        warning('Unexpected response type')
end



for i=1:100
  nonz1(i)=nnz(temp1(:,i)) ;
end
num_nonz=find(nonz1<=size(X,2)*prcnt);
temp1=temp1(:,num_nonz(end));
nnz(temp1);


lam_ind=min(1/4*sqrt(nnz(temp1)/n)*norm(temp1,2)*sqrt(log(p)/n),lambda11(101-num_nonz(end)));
