function [b1,b2,b3,stab,path] = Fusion(X, Y, p1,p2,tau,c,prcnt,resp)

tau1=tau;
tau2=tau;
tau3=tau;


mn=mean(X);
sd=sqrt(var(X));
cntr=bsxfun(@minus,X,mn);
X=bsxfun(@rdivide,cntr,sd); 

[n,p]=size(X);


p3=p-p1-p2;

X1_raw=X(:,1:p1);
X2_raw=X(:,p1+1:p1+p2);
X3_raw=X(:,p1+p2+1:end);



Y_raw=Y;


b1=zeros(p1,1);
b2=zeros(p2,1);
b3=zeros(p3,1);



N=200; 



for nn=1:N

sample_ind(:,nn) = randsample(n,n,true);
end



thr = 1.0e-3; iter = 1; globind=1;  thr1=1.0e-3; 


R1Final=[];
R2Final=[];
R3Final=[];


th1=[];
th2=[];
th3=[];




[lam_ind1,temp1,lambda11] = InitialLambda(X1_raw,Y_raw,n,p1,prcnt,resp);


[lam_ind2,temp2,lambda22] = InitialLambda(X2_raw,Y_raw,n,p2,prcnt,resp);


[lam_ind3,temp3,lambda33] = InitialLambda(X3_raw,Y_raw,n,p3,prcnt,resp);



x2=X2_raw(:,[]);
x3=X3_raw(:,[]);


path=[temp1;temp2;temp3];



    while globind>thr1 && iter<20
        
        b1_old=b1;
        b2_old=b2;
        b3_old=b3;



        



         for ii=1:N             
             Xxy=X(sample_ind(:,ii),:);
             mn=mean(Xxy);
             sd=sqrt(var(Xxy));
             cntr=bsxfun(@minus,Xxy,mn);
             stdX=bsxfun(@rdivide,cntr,sd);
             
             
             X1=stdX(:,1:p1);
             X2=stdX(:,1+p1:p1+p2);
             X3=stdX(:,1+p1+p2:p1+p2+p3);
             
             X_block=X1;
             X_non_block=[X2,X3];
             b_non_block=[b2;b3];   
             
             Yuse=Y_raw(sample_ind(:,ii),:);

             [R1] = LassoBlock(X_block,X_non_block,Yuse,lam_ind1,b_non_block,temp1,resp); 

             
             FinR1(:,ii)=R1(1:p1);
             m=nnz(R1(1:p1));
         end
         R1Final=[R1Final,FinR1];
         
         Xnon_block_raw=[x2,x3];
         [b1,x1,th1] = BlockPostProcess(R1Final,tau1,Y_raw,X1_raw,Xnon_block_raw,resp,th1); 
         
         nnz(b1)

           

      
              
         for ii=1:N
             
             Xxy=X(sample_ind(:,ii),:);
             mn=mean(Xxy);
             sd=sqrt(var(Xxy));
             cntr=bsxfun(@minus,Xxy,mn);
             stdX=bsxfun(@rdivide,cntr,sd);
             
             
             X1=stdX(:,1:p1);
             X2=stdX(:,1+p1:p1+p2);
             X3=stdX(:,1+p1+p2:p1+p2+p3);

             
             X_block=X2;
             X_non_block=[X1,X3];
             b_non_block=[b1;b3];   
             
             Yuse=Y_raw(sample_ind(:,ii),:);
             
             [R2] = LassoBlock(X_block,X_non_block,Yuse,lam_ind2,b_non_block,temp2,resp); 

             
             FinR2(:,ii)=R2(1:p2);
             m=nnz(R2(1:p2));

         end
           R2Final=[R2Final,FinR2];
           Xnon_block_raw=[x1,x3];
           [b2,x2,th2] = BlockPostProcess(R2Final,tau2,Y_raw,X2_raw,Xnon_block_raw,resp,th2); 
         
           nnz(b2)            
            
            


         for ii=1:N
             
             Xxy=X(sample_ind(:,ii),:);
             mn=mean(Xxy);
             sd=sqrt(var(Xxy));
             cntr=bsxfun(@minus,Xxy,mn);
             stdX=bsxfun(@rdivide,cntr,sd);
             
             
             X1=stdX(:,1:p1);
             X2=stdX(:,1+p1:p1+p2);
             X3=stdX(:,1+p1+p2:p1+p2+p3);

             
             X_block=X3;
             X_non_block=[X1,X2];
             b_non_block=[b1;b2];   
             
             Yuse=Y_raw(sample_ind(:,ii),:);
             
             [R3] = LassoBlock(X_block,X_non_block,Yuse,lam_ind3,b_non_block,temp3,resp); 

             
             FinR3(:,ii)=R3(1:p3);
             m=nnz(R3(1:p3));

         end
           R3Final=[R3Final,FinR3];
           Xnon_block_raw=[x1,x2];
           [b3,x3,th3] = BlockPostProcess(R3Final,tau3,Y_raw,X3_raw,Xnon_block_raw,resp,th3); 
         
           nnz(b3)            

           

        temp1=b1;
        temp2=b2;
        temp3=b3;

        betaest=[temp1;temp2;temp3];
        est=X*betaest;

switch resp
    case 'normal'
        z = eye(n);    
        
    case 'binomial'
        odds=exp(est);
        prob=1./(1+odds);
        w=prob.*(1-prob);
        z = diag(w);  
        
    case 'poisson'
        odds=exp(est);
        z = diag(odds);
        
    otherwise
        warning('Unexpected response type')
end        
        

        


        tempMtrx=X'*z*X;
        tempMtrx2=X'*X;
        c=abs(eigs(tempMtrx,1)/eigs(tempMtrx2,1))
            
            
        lam_ind1=max(c*sqrt(nnz(temp1)/n)*norm(temp1(temp1~=0),2)*sqrt(log(p1)/n),lambda11(30));

        lam_ind2=max(c*sqrt(nnz(temp2)/n)*norm((temp2(temp2~=0)),2)*sqrt(log(p2)/n),lambda22(30));

        lam_ind3=max(c*sqrt(nnz(temp3)/n)*norm(temp3,2)*sqrt(log(p3)/n),lambda33(30));
    

            
        if nnz(b1)>=size(X1_raw,2)*.2
            lam_ind1=lam_ind1*2
        end
        
        if nnz(b2)>=size(X2_raw,2)*.2
            lam_ind2=lam_ind2*2
        end
        
        if nnz(b3)>=size(X3_raw,2)*.2
            lam_ind3=lam_ind3*2
        end
        
  

        path=[path,[temp1;temp2;temp3]];

         globind=norm(b1-b1_old,2)+norm(b2-b2_old,2)+norm(b3-b3_old,2)
         iter = iter + 1;
    end
 

        stab=[th1(:,end);th2(:,end);th3(:,end)];
    
    
end









