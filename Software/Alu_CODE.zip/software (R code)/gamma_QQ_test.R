### QQ-test for the empirical distribution of Alu density agaist a Gamma distribution 


id=which(as.character(dat$chrom)=="chr22")
dat1=dat[id,]
p1=length(which(dat1$denIntrAlu==0))/length(id)
id=which(dat1$denIntrAlu!=0)
x=dat1[id,3]
es=fitdistr(x,"gamma")
shape=es$estimate[1]
scale=1.0/es$estimate[2]
curve_1=curve(dgamma(x, scale=scale, shape=shape),from=0, to=5,n=500, xlab="Alu density", ylab="Density of probability")

max=4

s=rgamma(n=length(x), scale=scale, shape=shape)
 qqplot(x,s, main="QQ-plot distr. Gamma. Chr-22",cex=.5,xlim=c(0,max),ylim=c(0,max), 
        ylab = "Theoretical Quantiles", xlab = "Sample Quantiles")
lines(c(0,max),c(0,max),col="red")

