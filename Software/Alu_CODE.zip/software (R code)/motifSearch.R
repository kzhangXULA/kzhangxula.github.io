### A function to map DNA motifs from human genome 

motifSearch=function(ch,str){
  library(BSgenome)
  library(BSgenome.Hsapiens.UCSC.hg18)
  
  if(ch==1)a=Hsapiens$chr1;
  if(ch==2)a=Hsapiens$chr2; 
  if(ch==3)a=Hsapiens$chr3;
  if(ch==4)a=Hsapiens$chr4; 
  if(ch==5)a=Hsapiens$chr5;
  if(ch==6)a=Hsapiens$chr6; 
  if(ch==7)a=Hsapiens$chr7;
  if(ch==8)a=Hsapiens$chr8; 
  if(ch==9)a=Hsapiens$chr9;
  if(ch==10)a=Hsapiens$chr10; 
  if(ch==11)a=Hsapiens$chr11;
  if(ch==12)a=Hsapiens$chr12; 
  if(ch==13)a=Hsapiens$chr13;
  if(ch==14)a=Hsapiens$chr14; 
  if(ch==15)a=Hsapiens$chr15;
  if(ch==16)a=Hsapiens$chr16;
  if(ch==17)a=Hsapiens$chr17;
  if(ch==18)a=Hsapiens$chr18; 
  if(ch==19)a=Hsapiens$chr19;
  if(ch==20)a=Hsapiens$chr20; 
  if(ch==21)a=Hsapiens$chr21;
  if(ch==22)a=Hsapiens$chr22; 
  if(ch=="X")a=Hsapiens$chrX; 
  if(ch=="Y")a=Hsapiens$chrY;
    
  chr=paste("chr",ch)
  chr=paste(chr,str,sep="_")

  loc=matchPattern(str,a,max.mismatch=0)
  name=paste(diGC,"/",chr,".txt",sep="")
  loc=as.data.frame(loc,col.names=c("start","end","motif_length"))

  write.table(loc,
              file=name,col.names=TRUE,
              row.names=FALSE,sep="\t",quote=FALSE)

  list(OT=loc)
}
