#### Two-step analysis for the association between Alu elements and TTAAAA motifs


fea=read.table("wholeGenomeData.txt", header=TRUE, sep="\t")
id=which(fea$lIntrSeq>0)
dat=fea[id,c(1,2,7,14,19,9,53,50,15,29,52,54,55)]

headline=c("chr",
          "m1.x1.c","m1.x1.p","m1.x1.r2","m1.x2.c","m1.x2.p","m1.x2.r2","m1.x3.c","m1.x3.p","m1.x3.r2",
          "m1.xc.c1","m1.xc.p1","m1.xc.c2","m1.xc.p2","m1.xc.r2",
          "m2.x1.c","m2.x1.p","m2.x1.r2","m2.x2.c","m2.x2.p","m2.x2.r2","m2.x3.c","m2.x3.p","m2.x3.r2",
          "m2.xc.c1","m2.xc.p1","m2.xc.c2","m2.xc.p2","m2.xc.r2")

write.table(t(headline),file="twoStepRegressionAnalysis_res_2.txt",col.names=F,row.names=F,sep="\t",quote=F)



for(i in 1:24){
  
  print(i)
 
  cx=i
  if(i==23)cx="X"
  if(i==24)cx="Y"
  ch=paste("chr",cx,sep="")
  id=which(as.character(dat$chrom)==ch)
  dat1=dat[id,]
  n=length(id)
  p=length(which(dat1$denIntrAlu==0))/length(id)
 
  y=dat1$denIntrAlu

  x1=dat1$denIntrMotif_TTAAAA
  x2=dat1$denIntrMotif_CCTCCCT
  x3=dat1$intrCG

  L=log10(dat1$lIntrSeq+dat1$lExonSeq)

  id=which(y>0)
  m1.x1=lm(log(y[id])~x1[id]+L[id])
  m1.x2=lm(log(y[id])~x2[id]+L[id])
  m1.x3=lm(log(y[id])~x3[id]+L[id])
  m1.xc=lm(log(y[id])~x1[id]+x2[id]+L[id])
  m1.L=lm(log(y[id])~L[id])

 
  y=rep(0,n)
  y[id]=1
  m2.x1=lrm(y~x1+L)
  m2.x2=lrm(y~x2+L)
  m2.x3=lrm(y~x3+L)
  m2.xc=lrm(y~x1+x2+L)
  m2.L=lrm(y~L)


  m1.x1.c=summary(m1.x1)$coefficients[2,1];m1.x1.p=summary(m1.x1)$coefficients[2,4]
     m1.x1.r2=summary(m1.x1)$adj.r.squared-summary(m1.L)$adj.r.squared
  m1.x2.c=summary(m1.x2)$coefficients[2,1];m1.x2.p=summary(m1.x2)$coefficients[2,4]
     m1.x2.r2=summary(m1.x2)$adj.r.squared-summary(m1.L)$adj.r.squared
  m1.x3.c=summary(m1.x3)$coefficients[2,1];m1.x3.p=summary(m1.x3)$coefficients[2,4]
     m1.x3.r2=summary(m1.x3)$adj.r.squared-summary(m1.L)$adj.r.squared

  m1.xc.c1=summary(m1.xc)$coefficients[2,1];m1.xc.p1=summary(m1.xc)$coefficients[2,4]
  m1.xc.c2=summary(m1.xc)$coefficients[3,1];m1.xc.p2=summary(m1.xc)$coefficients[3,4]
     m1.xc.r2=summary(m1.xc)$adj.r.squared-summary(m1.L)$adj.r.squared


  #id=which(x1>0)
  #x1=0
  #x1[id]=1




  m2.x1.c=m2.x1$coefficients[2];m2.x1.p=anova(m2.x1)[1,3]
     m2.x1.r2=m2.x1$stats[10]-m2.L$stats[10]
  m2.x2.c=m2.x2$coefficients[2];m2.x2.p=anova(m2.x2)[1,3]
     m2.x2.r2=m2.x2$stats[10]-m2.L$stats[10]
  m2.x3.c=m2.x3$coefficients[2];m2.x3.p=anova(m2.x3)[1,3]
     m2.x3.r2=m2.x3$stats[10]-m2.L$stats[10]

  m2.xc.c1=m2.xc$coefficients[2];m2.xc.p1=anova(m2.xc)[1,3]
  m2.xc.c2=m2.xc$coefficients[3];m2.xc.p2=anova(m2.xc)[2,3]
     m2.xc.r2=m2.xc$stats[10]-m2.L$stats[10]


  out=c(ch,
     m1.x1.c,m1.x1.p,m1.x1.r2,m1.x2.c,m1.x2.p,m1.x2.r2,m1.x3.c,m1.x3.p,m1.x3.r2,
     m1.xc.c1,m1.xc.p1,m1.xc.c2,m1.xc.p2,m1.xc.r2, 
     m2.x1.c,m2.x1.p,m2.x1.r2,m2.x2.c,m2.x2.p,m2.x2.r2,m2.x3.c,m2.x3.p,m2.x3.r2,
     m2.xc.c1,m2.xc.p1,m2.xc.c2,m2.xc.p2,m2.xc.r2)

  write.table(t(out),file="twoStepRegressionAnalysis_res_2.txt",col.names=F,row.names=F,sep="\t",quote=F, appen=T)
  
}



res=read.table("twoStepRegressionAnalysis_res_2.txt",header=T,sep="\t")
v1=p.adjust(res$m1.x1.p,method="BH")
v2=p.adjust(res$m2.x1.p,method="BH")
plot(-log10(v1),-log10(v2),xlab="-log10(adj.p),model-1",ylab="-log10(adj.p),model-2",type="n",xlim=c(0,15),ylim=c(0,12))
text(-log10(v1),-log10(v2),c(1:22,"X","Y"),cex=.7)
abline(v=1.3,lty="dashed",col="red")
abline(h=1.3,lty="dashed",col="red")

print("end")



              











 