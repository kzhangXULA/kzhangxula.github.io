#############################################################################################################################################
## The module for computing the within-gene densities of L1 elements and TTAAAA/TTAAGA motifs and the relevant genomic features. 
#############################################################################################################################################



################
exonMotif=function(en,eb,ee,ex,lo){

  write.table(eb, file="temp1.txt", col.names=FALSE,row.names=FALSE,quote=FALSE)
  write.table(ee, file="temp2.txt", col.names=FALSE,row.names=FALSE,quote=FALSE)
  b=read.table("temp1.txt",header=FALSE,sep=",")
  e=read.table("temp2.txt",header=FALSE,sep=",")
  
  b=as.integer(b[1:en]);e=as.integer(e[1:en]) 

  b=b-ex
  e=e+ex

  n=rep(0,en);l=rep(0,en)
  for(r in 1:en){
    id=which(lo[,1]>=b[r]&lo[,2]<=e[r])
    n[r]=length(id)
    l[r]=e[r]-b[r]
  }

  N=sum(n);R=sum(l)
  list(OT=N,OT1=R)
}
####################


####################
L1Motif=function(bd,lo){

  en=dim(bd)[1]
  b=as.integer(bd[1:en,1]);e=as.integer(bd[1:en,2]) 
  n=rep(0,en);l=rep(0,en)
  for(r in 1:en){
    id=which(lo[,1]>=b[r]&lo[,2]<=e[r])
    n[r]=length(id)
    l[r]=e[r]-b[r]
  }
  
  N=sum(n);R=sum(l)
  list(OT=N,OT1=R)
}
####################




###################
exonCG=function(genome,eb,ee){

  write.table(eb, file="temp1.txt", col.names=FALSE,row.names=FALSE,quote=FALSE)
  write.table(ee, file="temp2.txt", col.names=FALSE,row.names=FALSE,quote=FALSE)
  b=read.table("temp1.txt",header=FALSE,sep=",")
  e=read.table("temp2.txt",header=FALSE,sep=",")
  
  en=length(b)-1
  b=as.integer(b[1:en]);e=as.integer(e[1:en]) 

  n=rep(0,en);Tb=Cg=rep(0,en)
  for(r in 1:en){
    X=subseq(genome,b[r],e[r]) 
    Y=as.character(X)
    S=s2c(Y)
    sl=length(S)
    cg=GC(S)
    Tb[r]=sl
    Cg[r]=round(sl*cg,0)    
  }

  list(OT=c(sum(Tb),sum(Cg)))
}
####################


####################
L1CG=function(genome,bd){

  en=dim(bd)[1]
  b=as.integer(bd[1:en,1]);e=as.integer(bd[1:en,2])

  n=rep(0,en);Tb=Cg=rep(0,en)
  for(r in 1:en){
    X=subseq(genome,b[r],e[r]) 
    Y=as.character(X)
    S=s2c(Y)
    sl=length(S)
    cg=GC(S)
    Tb[r]=sl
    Cg[r]=round(sl*cg,0)    
  }

  list(OT=c(sum(Tb),sum(Cg)))
}
####################


####################
geneCG=function(genome,b,e){
    X=subseq(genome,b,e) 
    Y=as.character(X)
    S=s2c(Y)
    sl=length(S)
    cg=GC(S)
    Tb=sl
    Cg=round(sl*cg,0)    
 
  list(OT=c(Tb,Cg))
}
####################















####################
motifMap=function(idChr,str){

  #idChr=1
  #str="TTAAA"


  ####### string reverse
  str1=str
  s=nchar(str)
  t=substring(str,1:s,1:s)
  t=t[s:1]

  str2="A"
  for(k in 1:s){
    if(t[k]=="A")str2=paste(str2,"T",sep="")
    if(t[k]=="T")str2=paste(str2,"A",sep="") 
    if(t[k]=="C")str2=paste(str2,"G",sep="")
    if(t[k]=="G")str2=paste(str2,"C",sep="")
  }

  str2=substr(str2,2,s+1) 
  ########### 

 
  gene=read.table("refFlat_repDel.txt", header=TRUE, sep="\t")
  gene=gene[,1:11]
  #write.table(gene, file="gene-annotation.txt",col.names=TRUE, row.names=FALSE, sep="\t")

  chr=paste("chr",idChr,sep="")
  id=which(gene[,3]==chr)
  
  cGene=gene[id,]
  nGene=length(id)


  nMotif=rep(0,nGene)
  nExonMotif=rep(0,nGene)
  nIntrMotif=rep(0,nGene)

  nL1Intr=rep(0,nGene)
  nL1Exc=rep(0,nGene)
  nL1Exd=rep(0,nGene)
  nL1Pro=rep(nGene,0)

  lGeneSeq=rep(0,nGene)
  lExonSeq=rep(0,nGene)
  lIntrSeq=rep(0,nGene)

  denIntrMotif=rep(0,nGene)
  denExonMotif=rep(0,nGene)
  denIntrL1=rep(0,nGene)
  denExonL1=rep(0,nGene)

  exonCG=rep(0,nGene)
  intrCG=rep(0,nGene)


  #### L1Intr and other were prepared from running "L1Data.txt"
  id=which(L1Intr[,3]==chr);L1Intr=L1Intr[id,]
  id=which(L1Exd[,3]==chr);L1Exd=L1Exd[id,]
  id=which(L1Exc[,3]==chr);L1Exc=L1Exc[id,]
  id=which(L1Pro[,3]==chr);L1Pro=L1Pro[id,]
  ###########


  source("motifSearch.R")
  loc1=motifSearch(idChr,str1)$OT
  loc2=motifSearch(idChr,str2)$OT
  
  source("seqRetr.R")
  genome=seqRetr(idChr)$OT


  for(i in 1:nGene){
   
     print(i)

     id=which(loc1[,1]>=cGene[i,5]&loc1[,2]<=cGene[i,6])
     if(cGene[i,4]=="-")id=which(loc2[,1]>=cGene[i,5]&loc2[,2]<=cGene[i,6])  
     nMotif[i]=length(id)

     flnk=0
     lo=loc1
     if(cGene[i,4]=="-")lo=loc2
     exon=exonMotif(cGene[i,9],cGene[i,10],cGene[i,11],flnk,lo)
     nExonMotif[i]=exon$OT
     nIntrMotif[i]=nMotif[i]-nExonMotif[i]

     lGeneSeq[i]=cGene[i,6]-cGene[i,5]
     lExonSeq[i]=exon$OT1

     lIntrSeq[i]=max(lGeneSeq[i]-lExonSeq[i],0)

     id=which(L1Exd[,5]>=cGene[i,5]&L1Exd[,6]<=cGene[i,6])
     nL1Exd[i]=length(id)

     id=which(L1Exc[,5]>=cGene[i,5]&L1Exc[,6]<=cGene[i,6])
     nL1Exc[i]=length(id)

     id=which(L1Intr[,5]>=cGene[i,5]&L1Intr[,6]<=cGene[i,6])
     nL1Intr[i]=length(id)
    
     if(nL1Intr[i]>0){
       lsL1Intr=L1Intr[id,c(5,6)]
       intr=L1Motif(lsL1Intr,lo)
       nIntrMotif[i]=nIntrMotif[i]-intr$OT
       lIntrSeq[i]=lIntrSeq[i]-intr$OT1
     }
      
     id=which(L1Pro[,5]>=cGene[i,5]&L1Pro[,6]<=cGene[i,6])
     nL1Pro[i]=length(id)

     if(lIntrSeq[i]>0)denIntrMotif[i]=round(nIntrMotif[i]/lIntrSeq[i]*1000,6)
     denExonMotif[i]=round(nExonMotif[i]/lExonSeq[i]*1000,6)
   
     if(lIntrSeq[i]>0)denIntrL1[i]=round((nL1Intr[i]+nL1Pro[i])/lIntrSeq[i]*1000,6)
     denExonL1[i]=round((nL1Exc[i]+nL1Exd[i])/lExonSeq[i]*1000,6)

     ####
     t3=c(0,0)
     t1=geneCG(genome,cGene[i,5],cGene[i,6])$OT      
     t2=exonCG(genome,cGene[i,10],cGene[i,11])$OT    
     if(nL1Intr[i]>0)t3=L1CG(genome,lsL1Intr)$OT   
 
     exonCG[i]=round(t2[2]/t2[1],4)
     intrCG[i]=round((t1[2]-t2[2]-t3[2])/(t1[1]-t2[1]-t3[1]),4)  
     if(cGene[i,4]=="-"){exonCG[i]=1-exonCG[i];intrCG[i]=1-intrCG[i]}
           
  }   


  
  data=cbind(cGene[,1:9],lGeneSeq,lExonSeq,lIntrSeq,nL1Exd,nL1Exc,nL1Pro,nL1Intr,nMotif,
             nExonMotif,nIntrMotif,denIntrMotif,denExonMotif,denIntrL1,denExonL1)

  CG=cbind(data,exonCG,intrCG)
  
  m=dim(data)[2]
  id=sort(data[,m-3],index=TRUE)$ix   
  data=data[id,]

  name=paste(diGC,"/gene_annotation_",chr,"_",str,"_SortOnMotifDensity",".txt",sep="")
  write.table(data,file=name, col.names=TRUE,row.names=FALSE, sep="\t",quote=FALSE)

  id=sort(data[,m-1],index=TRUE)$ix   
  data=data[id,]

  name=paste(diGC,"/gene_annotation_",chr,"_",str,"_SortOnL1Density",".txt",sep="")
  write.table(data,file=name, col.names=TRUE,row.names=FALSE, sep="\t",quote=FALSE)

  denIntrMotif_GW=round(sum(nIntrMotif)/sum(lIntrSeq)*1000,6)
  denExonMotif_GW=round(sum(nExonMotif)/sum(lExonSeq)*1000,6)
  denIntrL1_GW=round(sum(nL1Intr+nL1Pro)/sum(lIntrSeq)*1000,6)
  denExonL1_GW=round(sum(nL1Exd+nL1Exc)/sum(lExonSeq)*1000,6)

  denGW=t(c(denIntrMotif_GW,denExonMotif_GW,denIntrL1_GW,denExonL1_GW))

  summ=colMeans(data[,10:m])
  summ=c(as.character(cGene[2,3]),summ,denGW)
  write.table(t(summ),file=sumFile,col.names=FALSE,row.names=FALSE,sep="\t",quote=FALSE,appen=TRUE)

  name=paste(diGC,"/gene_annotation_",chr,"_",str,"_CG",".txt",sep="")
  write.table(CG,file=name, col.names=TRUE,row.names=FALSE, sep="\t",quote=FALSE)
 
}




















