#### Program for analizing the Alu-related genome features of cancer genes


fea=read.table("wholeGenomeData.txt", header=TRUE, sep="\t")
id=which(fea$lIntrSeq>0)
dat=fea[id,]    #[id,c(1,14,19,9,53,50,15,29,52,54,55)]

name="CancerGneneSanger.txt"
gn=read.table(name,header=F, sep="\t")

a=match(dat[,1],gn[,1])
g1=which(a!="NA")
g=rep(0,dim(dat)[1])
g[g1]=1
g2=which(g==0)    

x=dat[g1,4]
y=dat[g2,4]

px=length(which(x==0))/length(x)
py=length(which(y==0))/length(y)

ix=which(x!=0)
x1=x[ix]
iy=which(y!=0)
y1=y[iy]

es_x=fitdistr(x1,"gamma")
es_y=fitdistr(y1,"gamma")

shape_x=es_x$estimate[1]
scale_x=1.0/es_y$estimate[2]

shape_y=es_y$estimate[1]
scale_y=1.0/es_y$estimate[2]

curve_x=curve(dgamma(x, scale=scale_x, shape=shape_x),from=0, to=6, n=500)
curve_y=curve(dgamma(x, scale=scale_y, shape=shape_y),from=0, to=6, n=500)

plot(c(0,6),c(0,1.0),xlab="Density of Alu repeats",ylab="Adjusted density of probability",cex=.6)
curve(dgamma(x, scale=scale_x, shape=shape_x),from=0, to=6, n=500,add=T, col="red")
curve(dgamma(x, scale=scale_y, shape=shape_y),from=0, to=6, n=500,add=T,col="blue")



#lines(curve_x$x,curve_x$y*(1-px),col="red",add=T)
#lines(curve_y$x,curve_y$y*(1-py),col="blue", add=T)

#barplot(c(px, py),col=c("red","blue"),ylab="Proportion of genes lack of Alu")















