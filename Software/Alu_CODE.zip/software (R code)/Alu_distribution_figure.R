### Program for modeling and visualizing Alu distribution


fea=read.table("wholeGenomeData.txt", header=TRUE, sep="\t")
id=which(fea$lIntrSeq>0)
dat=fea[id,c(1,2,14,19,9,53,50,15,29,52,54,55)]

id=which(as.character(dat$chrom)=="chr1")
dat1=dat[id,]
p1=length(which(dat1$denIntrAlu==0))/length(id)
id=which(dat1$denIntrAlu!=0)
x=dat1[id,3]
es=fitdistr(x,"gamma")
shape=es$estimate[1]
scale=1.0/es$estimate[2]
curve_1=curve(dgamma(x, scale=scale, shape=shape),from=0, to=5,n=500, xlab="Alu density", ylab="Density of probability")


id=which(as.character(dat$chrom)=="chr19")
dat1=dat[id,]
p19=length(which(dat1$denIntrAlu==0))/length(id)
id=which(dat1$denIntrAlu!=0)
x=dat1[id,3]
es=fitdistr(x,"gamma")
shape=es$estimate[1]
scale=1.0/es$estimate[2]
curve_19=curve(dgamma(x, scale=scale, shape=shape),from=0, to=6,n=500, xlab="Alu density", ylab="Density of probability")


id=which(as.character(dat$chrom)=="chrX")
dat1=dat[id,]
pX=length(which(dat1$denIntrAlu==0))/length(id)
id=which(dat1$denIntrAlu!=0)
x=dat1[id,3]
es=fitdistr(x,"gamma")
shape=es$estimate[1]
scale=1.0/es$estimate[2]
curve_X=curve(dgamma(x, scale=scale, shape=shape),from=0, to=5,n=500, xlab="Alu density", ylab="Density of probability")

id=which(as.character(dat$chrom)=="chrY")
dat1=dat[id,]
pY=length(which(dat1$denIntrAlu==0))/length(id)
id=which(dat1$denIntrAlu!=0)
x=dat1[id,3]
es=fitdistr(x,"gamma")
shape=es$estimate[1]
scale=1.0/es$estimate[2]
curve_Y=curve(dgamma(x, scale=scale, shape=shape),from=0, to=5,n=500, xlab="Alu density", ylab="Density of probability")


plot(c(0,6),c(0,.85),xlab="Density of Alu repeats",ylab="Adjusted density of probabilty", cex=.8)
lines(curve_1$x,curve_1$y*(1-p1),col="black")
lines(curve_19$x,curve_19$y*(1-p19),col="blue")
lines(curve_X$x,curve_X$y*(1-pX),col="green")
lines(curve_Y$x,curve_Y$y*(1-pY),col="red")
#barplot(c(p1,p19,pX,pY),col=c("black","blue","green","red"),names.arg=c("chr1","chr19","chrX","chrY"),
#        ylab="Proportion of genes lack of Alu")



#sub=paste("scale = ",round(scale,3),"    ","shape = ",round(shape,3),sep="")
#hist(x,freq=F,xlab="Density of Alu repeats", ylab="Density of probability", main=NULL,sub=sub)









