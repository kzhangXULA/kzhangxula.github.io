### Visualization of two-step analysis 

x=read.table("twoStepRegressionAnalysis_res_2.txt", header=T, sep="\t")


 p1=x$m1.x1.p
 p2=x$m2.x1.p
 adj.p1=p.adjust(p1, method="BH")
 adj.p2=p.adjust(p2, method="BH")

 xlab="-log10 (adj.p), model-2"
 ylab="-log10 (adj.p), model-1" 

 col=rep("black",24)
 col[c(7,23)]="blue"

 plot(-log10(adj.p1),-log10(adj.p2), type="n", xlab=xlab, ylab=ylab)
 abline(h=1.3, col="red", lty="dashed")
 abline(v=1.3, col="red", lty="dashed")
 text(-log10(adj.p1),-log10(adj.p2),c(1:22,"X","Y"),col=col, cex=.8)
