#############################################################################################################################################
## The main prgram for computing the within-gene densities of Alu/L1 elementsan TTAAAA/TTAAGA motifs and the relevant genomic features. 
## Four seperately-filed modules, including "aluData.R", "ExonMotifMapAlu.R",including "L1Data.R", "ExonMotifMapL1.R" will be prompted by the ## program.
#############################################################################################################################################

#Copyright: Wensheng Zhang and Kun Zhang
# If you use the code in this package,
# Please cite "Alu Distribution and Mutation Types of Cancer Genes", BMC Genomics, 2011, March, 12:157, doi:10.1186/1471-2164-12-157, PMID:21429208

##################### Alu TTAAAA ##################


rm(list=ls())
library(seqinr)
source("aluData.R")

motif="TTAAAA"
di=paste("result_",motif,sep="")
#dir.create(di,showWarnings=FALSE)

diGC=paste(di,"_Alu","_GC",sep="")
dir.create(diGC,showWarnings=FALSE)

dir.create("summary_Alu",showWarnings=FALSE)
sumFile=paste("summary_Alu/",motif,".txt",sep="")
head=c("Chr","lGeneSeq","lExonSeq","lIntrSeq","nAluExd","nAluExc","nAluPro","nAluIntr","nMotif",
       "nExonMotif","nIntrMotif","denIntrMotif","denExonMotif","denIntrAlu","denExonAlu",
       "denIntrMotif_GW","denExonMotif_GW","denIntrAlu_GW","denExonAlu_GW")
write.table(t(head),file=sumFile,col.names=FALSE,row.names=FALSE,sep="\t",quote=FALSE,appen=FALSE)
 

for(j in 1:24){
  cx=j
  if(j==23)cx="X"
  if(j==24)cx="Y"
  source("ExonMotifMapAlu.R")
  motifMap(cx,motif)
}



##################### Alu TTAAGA  ##################


rm(list=ls())
library(seqinr)
source("aluData.R")

motif="TTAAGA"
di=paste("result_",motif,sep="")
#dir.create(di,showWarnings=FALSE)

diGC=paste(di,"_Alu","_GC",sep="")
dir.create(diGC,showWarnings=FALSE)

dir.create("summary_Alu",showWarnings=FALSE)
sumFile=paste("summary_Alu/",motif,".txt",sep="")
head=c("Chr","lGeneSeq","lExonSeq","lIntrSeq","nAluExd","nAluExc","nAluPro","nAluIntr","nMotif",
       "nExonMotif","nIntrMotif","denIntrMotif","denExonMotif","denIntrAlu","denExonAlu",
       "denIntrMotif_GW","denExonMotif_GW","denIntrAlu_GW","denExonAlu_GW")
write.table(t(head),file=sumFile,col.names=FALSE,row.names=FALSE,sep="\t",quote=FALSE,appen=FALSE)
 

for(j in 1:24){
  cx=j
  if(j==23)cx="X"
  if(j==24)cx="Y"
  source("ExonMotifMapAlu.R")
  motifMap(cx,motif)
}



###################### L1 TTAAAA ############################

rm(list=ls())
library(seqinr)
source("L1Data.R")


motif="TTAAAA"
di=paste("result_",motif,sep="")
#dir.create(di,showWarnings=FALSE)

diGC=paste(di,"_L1","_GC",sep="")
dir.create(diGC,showWarnings=FALSE)

dir.create("summary_L1",showWarnings=FALSE)
sumFile=paste("summary_L1/",motif,".txt",sep="")
head=c("Chr","lGeneSeq","lExonSeq","lIntrSeq","nL1Exd","nL1Exc","nL1Pro","nL1Intr","nMotif",
       "nExonMotif","nIntrMotif","denIntrMotif","denExonMotif","denIntrL1","denExonL1",
       "denIntrMotif_GW","denExonMotif_GW","denIntrL1_GW","denExonL1_GW")
write.table(t(head),file=sumFile,col.names=FALSE,row.names=FALSE,sep="\t",quote=FALSE,appen=FALSE)
 

for(j in 2:24){
  cx=j
  if(j==23)cx="X"
  if(j==24)cx="Y"
  source("ExonMotifMapL1.R")
  motifMap(cx,motif)
}



########## L1 TTAAGA #############
rm(list=ls())
library(seqinr)
source("L1Data.R")

motif="TTAAGA"
di=paste("result_",motif,sep="")
#dir.create(di,showWarnings=FALSE)

diGC=paste(di,"_L1","_GC",sep="")
dir.create(diGC,showWarnings=FALSE)

dir.create("summary_L1",showWarnings=FALSE)
sumFile=paste("summary_L1/",motif,".txt",sep="")
head=c("Chr","lGeneSeq","lExonSeq","lIntrSeq","nL1Exd","nL1Exc","nL1Pro","nL1Intr","nMotif",
       "nExonMotif","nIntrMotif","denIntrMotif","denExonMotif","denIntrL1","denExonL1",
       "denIntrMotif_GW","denExonMotif_GW","denIntrL1_GW","denExonL1_GW")
write.table(t(head),file=sumFile,col.names=FALSE,row.names=FALSE,sep="\t",quote=FALSE,appen=FALSE)
 

for(j in 1:24){
  cx=j
  if(j==23)cx="X"
  if(j==24)cx="Y"
  source("ExonMotifMapL1.R")
  motifMap(cx,motif)
}










