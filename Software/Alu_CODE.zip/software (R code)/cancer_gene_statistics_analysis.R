#### Program to perform the two-step statistical analysis for the association between Alu elements and TTAAAA mofifs


comb=function(dt){
  m=dim(dt)[2]
  dt=dt[,c(2,5:m)]
  m=m-3

  tb=table(as.character(dt[,1]))
  tb=names(tb)
  n=length(tb)
  tem=dt

  for(i in 1:n){
    id=which(as.character(dt[,1])==tb[i])
    tem[i,1]=tb[i]
    tem[i,2:m]=colMeans(dt[id,2:m])
  }

  list(OT=tem[1:n,])
}


dataMatch=function(dat1,dat2){
   ls1=dat1[,1];ls2=dat2[,1];n=length(ls1)
   a=match(ls1,ls2)
   b=which(a!="NA")
   ot1=dat1[b,]
   c=a[b]
   ot2=dat2[c,]
   list(OT1=ot1,OT2=ot2)
 }       


####### Main #######

#canc=read.table("fltMrnaList/cancerIndicator.txt", header=FALSE, sep="\t")
#canc=read.table("fltMrnaList/TGBD_mRNA.txt", header=FALSE, sep="\t")
canc=read.table("fltMrnaList/CancerGneneSanger.txt", header=FALSE, sep="\t")


alu=read.table("aluMotiffFeature.txt", header=T, sep="\t")
pair=read.table("GeneIntrAluPair_ex.txt", header=T, sep="\t")
feat=cbind(alu,pair[,4:24])

onc=read.table("fltMrnaList/oncogene.txt",header=FALSE, sep="\t")
sup=read.table("fltMrnaList/suppressor.txt",header=FALSE, sep="\t")

denAluPair=rowSums(feat[,32:47])/(feat$lIntrSeq+.001)*1000 
denIntrAluY=feat$nIntrAluY/(feat$lIntrSeq+.001)*1000
denIntr_hAluY=feat$hAluY/(feat$lIntrSeq+.001)*1000
denIntr_tAluY=feat$tAluY/(feat$lIntrSeq+.001)*1000
denIntr_htAluY=feat$htAluY/(feat$lIntrSeq+.001)*1000  

#denAluPair=(feat$CD_LL+feat$CD_SS+feat$CD_LS+feat$CD_SL+feat$DC_LL+feat$DC_SS+feat$DC_LS+feat$DC_SL/(feat$lIntrSeq+.001)*1000

feat=cbind(feat,denIntrAluY,denAluPair,denIntr_hAluY,denIntr_tAluY,denIntr_htAluY)

dt=dataMatch(canc,feat)$OT2
dy=comb(dt)$OT


#ls=c("CRB1","BRCA2","BRCA1","NF1","MLH1","MSH2","VHL","MYB","MLL","DFFB")
ls=c("BRCA2","BRCA1","MLH1","MSH2","VHL","MYB","MLL","DFFB","HIP1")


n=dim(dy)[1]
ct=rep("A",n)
a=match(dy[,1],ls)    #2
b=which(a!="NA")
ct[b]="B"
ct=as.factor(ct)

 
var1=dy$denIntrAlu
var2=dy$denIntrMotif_TTAAAA
var3=dy$intrCG
var4=dy$denAluPair
var5=dy$triplet
var6=dy$denExonAlu
var7=dy$denIntrMotif_CCTCCCT
var8=dy$denIntrAluY


x=cbind(var1,var3,var4,var5,var6,var8)
hc=hclust(dist(x),method="complete")
plot(hc, labels=FALSE,hang=-1)


var1=var1-var4
lm=lrm(ct~var1+var3+var5+var6)
anova(lm)


asw <- numeric(20)
for (k in 2:20)
  asw[k] <- pam(x, k) $ silinfo $ avg.width
k.best <- which.max(asw)
c1=as.factor(pam(x,k.best)$clustering)

























