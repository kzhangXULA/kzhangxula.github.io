#### ### The program for selecting the sebset for L1 elements from the downloaded datasets


L1Exd=read.csv("repDel_exonized_TE_hg18.txt", header=FALSE, sep="\t")
L1Exd=L1Exd[,c(1:6,24:25)]
id=which(substr(L1Exd[,2],1,2)=="L1")
L1Exc=L1Exd[id,]

L1Exc=read.csv("repDel_exonic_internal_TE_hg18.txt", header=FALSE, sep="\t")
L1Exc=L1Exc[,c(1:6,9,17)]
id=which(substr(L1Exc[,2],1,2)=="L1")
L1Exc=L1Exc[id,]

L1Pro=read.csv("repDel_TE_promoter_hg18.txt", header=FALSE, sep="\t")
L1Pro=L1Pro[,c(1:6,9,12)]
id=which(substr(L1Pro[,2],1,2)=="L1")
L1Pro=L1Pro[id,]

L1Intr=read.csv("repDel_TE_introns_hg18.txt", header=FALSE, sep="\t")
L1Intr=L1Intr[,c(1:6,11,15)]
id=which(substr(L1Intr[,2],1,2)=="L1")
L1Intr=L1Intr[id,]

write.table(L1Intr, "L1Intr_dat.txt",col.name=TRUE,row.names=FALSE,sep="\t",quote=FALSE)