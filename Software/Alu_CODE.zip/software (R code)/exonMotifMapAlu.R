#############################################################################################################################################
## The module for computing the within-gene densities of Alu elements and TTAAAA/TTAAGA motifs and the relevant genomic features. 
#############################################################################################################################################


################
exonMotif=function(en,eb,ee,ex,lo){

  write.table(eb, file="temp1.txt", col.names=FALSE,row.names=FALSE,quote=FALSE)
  write.table(ee, file="temp2.txt", col.names=FALSE,row.names=FALSE,quote=FALSE)
  b=read.table("temp1.txt",header=FALSE,sep=",")
  e=read.table("temp2.txt",header=FALSE,sep=",")
  
  b=as.integer(b[1:en]);e=as.integer(e[1:en]) 

  b=b-ex
  e=e+ex

  n=rep(0,en);l=rep(0,en)
  for(r in 1:en){
    id=which(lo[,1]>=b[r]&lo[,2]<=e[r])
    n[r]=length(id)
    l[r]=e[r]-b[r]
  }

  N=sum(n);R=sum(l)
  list(OT=N,OT1=R)
}
####################


####################
aluMotif=function(bd,lo){

  en=dim(bd)[1]
  b=as.integer(bd[1:en,1]);e=as.integer(bd[1:en,2]) 
  n=rep(0,en);l=rep(0,en)
  for(r in 1:en){
    id=which(lo[,1]>=b[r]&lo[,2]<=e[r])
    n[r]=length(id)
    l[r]=e[r]-b[r]
  }
  
  N=sum(n);R=sum(l)
  list(OT=N,OT1=R)
}
####################



###################
exonCG=function(genome,eb,ee){

  write.table(eb, file="temp1.txt", col.names=FALSE,row.names=FALSE,quote=FALSE)
  write.table(ee, file="temp2.txt", col.names=FALSE,row.names=FALSE,quote=FALSE)
  b=read.table("temp1.txt",header=FALSE,sep=",")
  e=read.table("temp2.txt",header=FALSE,sep=",")
  
  en=length(b)-1
  b=as.integer(b[1:en]);e=as.integer(e[1:en]) 

  n=rep(0,en);Tb=Cg=rep(0,en)
  for(r in 1:en){
    X=subseq(genome,b[r],e[r]) 
    Y=as.character(X)
    S=s2c(Y)
    sl=length(S)
    cg=GC(S)
    Tb[r]=sl
    Cg[r]=round(sl*cg,0)    
  }

  list(OT=c(sum(Tb),sum(Cg)))
}
####################


####################
aluCG=function(genome,bd){

  en=dim(bd)[1]
  b=as.integer(bd[1:en,1]);e=as.integer(bd[1:en,2])

  n=rep(0,en);Tb=Cg=rep(0,en)
  for(r in 1:en){
    X=subseq(genome,b[r],e[r]) 
    Y=as.character(X)
    S=s2c(Y)
    sl=length(S)
    cg=GC(S)
    Tb[r]=sl
    Cg[r]=round(sl*cg,0)    
  }

  list(OT=c(sum(Tb),sum(Cg)))
}
####################


####################
geneCG=function(genome,b,e){
    X=subseq(genome,b,e) 
    Y=as.character(X)
    S=s2c(Y)
    sl=length(S)
    cg=GC(S)
    Tb=sl
    Cg=round(sl*cg,0)    
 
  list(OT=c(Tb,Cg))
}
####################






####################
motifMap=function(idChr,str){

  #idChr=1
  #str="TTAAA"


  ####### string reverse
  str1=str
  s=nchar(str)
  t=substring(str,1:s,1:s)
  t=t[s:1]

  str2="A"
  for(k in 1:s){
    if(t[k]=="A")str2=paste(str2,"T",sep="")
    if(t[k]=="T")str2=paste(str2,"A",sep="") 
    if(t[k]=="C")str2=paste(str2,"G",sep="")
    if(t[k]=="G")str2=paste(str2,"C",sep="")
  }

  str2=substr(str2,2,s+1) 
  ########### 

 
  gene=read.csv("refFlat_repDel.txt", header=TRUE, sep="\t")
  gene=gene[,1:11]
  #write.table(gene, file="gene-annotation.txt",col.names=TRUE, row.names=FALSE, sep="\t")

  chr=paste("chr",idChr,sep="")
  id=which(gene[,3]==chr)

  
  cGene=gene[id,]
  nGene=length(id)

  nMotif=rep(0,nGene)
  nExonMotif=rep(0,nGene)
  nIntrMotif=rep(0,nGene)

  nAluIntr=rep(0,nGene)
  nAluExc=rep(0,nGene)
  nAluExd=rep(0,nGene)
  nAluPro=rep(nGene,0)

  lGeneSeq=rep(0,nGene)
  lExonSeq=rep(0,nGene)
  lIntrSeq=rep(0,nGene)

  denIntrMotif=rep(0,nGene)
  denExonMotif=rep(0,nGene)
  denIntrAlu=rep(0,nGene)
  denExonAlu=rep(0,nGene)

  exonCG=rep(0,nGene)
  intrCG=rep(0,nGene)


  #### aluIntr and other were prepared from running "aluData.txt"
  id=which(aluIntr[,3]==chr);aluIntr=aluIntr[id,]
  id=which(aluExd[,3]==chr);aluExd=aluExd[id,]
  id=which(aluExc[,3]==chr);aluExc=aluExc[id,]
  id=which(aluPro[,3]==chr);aluPro=aluPro[id,]
  ###########


  source("motifSearch.R")
  loc1=motifSearch(idChr,str1)$OT

  loc2=motifSearch(idChr,str2)$OT
  
  source("seqRetr.R")
  genome=seqRetr(idChr)$OT


  for(i in 1:nGene){
  
     print(i)
   
     id=which(loc1[,1]>=cGene[i,5]&loc1[,2]<=cGene[i,6])
     if(cGene[i,4]=="-")id=which(loc2[,1]>=cGene[i,5]&loc2[,2]<=cGene[i,6])  
     nMotif[i]=length(id)

     flnk=0
     lo=loc1
     if(cGene[i,4]=="-")lo=loc2
     exon=exonMotif(cGene[i,9],cGene[i,10],cGene[i,11],flnk,lo)
     nExonMotif[i]=exon$OT
     nIntrMotif[i]=nMotif[i]-nExonMotif[i]

     lGeneSeq[i]=cGene[i,6]-cGene[i,5]
     lExonSeq[i]=exon$OT1

     lIntrSeq[i]=max(lGeneSeq[i]-lExonSeq[i],0)

     id=which(aluExd[,5]>=cGene[i,5]&aluExd[,6]<=cGene[i,6])
     nAluExd[i]=length(id)

     id=which(aluExc[,5]>=cGene[i,5]&aluExc[,6]<=cGene[i,6])
     nAluExc[i]=length(id)

     id=which(aluIntr[,5]>=cGene[i,5]&aluIntr[,6]<=cGene[i,6])
     nAluIntr[i]=length(id)
    
     if(nAluIntr[i]>0){
       lsAluIntr=aluIntr[id,c(5,6)]
       intr=aluMotif(lsAluIntr,lo)
       nIntrMotif[i]=nIntrMotif[i]-intr$OT
       lIntrSeq[i]=lIntrSeq[i]-intr$OT1
     }
      
     id=which(aluPro[,5]>=cGene[i,5]&aluPro[,6]<=cGene[i,6])
     nAluPro[i]=length(id)

     if(lIntrSeq[i]>0)denIntrMotif[i]=round(nIntrMotif[i]/lIntrSeq[i]*1000,6)
     denExonMotif[i]=round(nExonMotif[i]/lExonSeq[i]*1000,6)
   
     if(lIntrSeq[i]>0)denIntrAlu[i]=round((nAluIntr[i]+nAluPro[i])/lIntrSeq[i]*1000,6)
     denExonAlu[i]=round((nAluExc[i]+nAluExd[i])/lExonSeq[i]*1000,6)

     ####
     t3=c(0,0)
     t1=geneCG(genome,cGene[i,5],cGene[i,6])$OT      
     t2=exonCG(genome,cGene[i,10],cGene[i,11])$OT    
     if(nAluIntr[i]>0)t3=aluCG(genome,lsAluIntr)$OT   
 
     exonCG[i]=round(t2[2]/t2[1],4)
     intrCG[i]=round((t1[2]-t2[2]-t3[2])/(t1[1]-t2[1]-t3[1]),4)  
     if(cGene[i,4]=="-"){exonCG[i]=1-exonCG[i];intrCG[i]=1-intrCG[i]}
           
  }   

  
  data=cbind(cGene[,1:9],lGeneSeq,lExonSeq,lIntrSeq,nAluExd,nAluExc,nAluPro,nAluIntr,nMotif,
             nExonMotif,nIntrMotif,denIntrMotif,denExonMotif,denIntrAlu,denExonAlu)

  CG=cbind(data,exonCG,intrCG)
  
  m=dim(data)[2]
  id=sort(data[,m-3],index=TRUE)$ix   
  data=data[id,]

  name=paste(diGC,"/gene_annotation_",chr,"_",str,"_SortOnMotifDensity",".txt",sep="")
  write.table(data,file=name, col.names=TRUE,row.names=FALSE, sep="\t",quote=FALSE)

  id=sort(data[,m-1],index=TRUE)$ix   
  data=data[id,]

  name=paste(diGC,"/gene_annotation_",chr,"_",str,"_SortOnAluDensity",".txt",sep="")
  write.table(data,file=name, col.names=TRUE,row.names=FALSE, sep="\t",quote=FALSE)

  denIntrMotif_GW=round(sum(nIntrMotif)/sum(lIntrSeq)*1000,6)
  denExonMotif_GW=round(sum(nExonMotif)/sum(lExonSeq)*1000,6)
  denIntrAlu_GW=round(sum(nAluIntr+nAluPro)/sum(lIntrSeq)*1000,6)
  denExonAlu_GW=round(sum(nAluExd+nAluExc)/sum(lExonSeq)*1000,6)

  denGW=t(c(denIntrMotif_GW,denExonMotif_GW,denIntrAlu_GW,denExonAlu_GW))

  summ=colMeans(data[,10:m])
  summ=c(as.character(cGene[2,3]),summ,denGW)
  write.table(t(summ),file=sumFile,col.names=FALSE,row.names=FALSE,sep="\t",quote=FALSE,appen=TRUE)

  name=paste(diGC,"/gene_annotation_",chr,"_",str,"_CG",".txt",sep="")
  write.table(CG,file=name, col.names=TRUE,row.names=FALSE, sep="\t",quote=FALSE)
  
  rm(list = ls()) 
}




















