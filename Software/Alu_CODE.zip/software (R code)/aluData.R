### The program for selecting the sebset for Alus from the downloaded datasets


aluExd=read.csv("repDel_exonized_TE_hg18.txt", header=FALSE, sep="\t")
aluExd=aluExd[,c(1:6,24:25)]
id=which(substr(aluExd[,2],1,3)=="Alu")
aluExc=aluExd[id,]

aluExc=read.csv("repDel_exonic_internal_TE_hg18.txt", header=FALSE, sep="\t")
aluExc=aluExc[,c(1:6,9,17)]
id=which(substr(aluExc[,2],1,3)=="Alu")
aluExc=aluExc[id,]

aluPro=read.csv("repDel_TE_promoter_hg18.txt", header=FALSE, sep="\t")
aluPro=aluPro[,c(1:6,9,12)]
id=which(substr(aluPro[,2],1,3)=="Alu")
aluPro=aluPro[id,]

aluIntr=read.csv("repDel_TE_introns_hg18.txt", header=FALSE, sep="\t")
aluIntr=aluIntr[,c(1:6,11,15)]
id=which(substr(aluIntr[,2],1,3)=="Alu")
aluIntr=aluIntr[id,]

write.table(aluIntr, "aluIntr_dat.txt",col.name=TRUE,row.names=FALSE,sep="\t",quote=FALSE)