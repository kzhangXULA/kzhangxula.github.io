#### Estimate the parameters of Gamma distribution.

par=matrix(0,24,5)
for(i in 1:24){
  cx=i
  if(i==23)cx="X"
  if(i==24)cx="Y"
  ch=paste("chr",cx,sep="")
  id=which(as.character(dat$chrom)==ch)
  dat1=dat[id,]
  n=length(id)
  p=length(which(dat1$denIntrAlu==0))/length(id)
  id=which(dat1$denIntrAlu!=0)
  x=dat1[id,3]
  es=fitdistr(x,"gamma")
  shape=es$estimate[1]
  scale=1.0/es$estimate[2]

  par[i,]=c(ch,n,round(p,3),round(shape,3),round(scale,3))
}

out=as.data.frame(par)
headline=c("chr","nGeneMultExon","pGeneLackAlu","shape","scale")

write.table(t(headline),file="parameter_res.txt",col.names=F, row.names=F, sep="\t", quote=F)
write.table(out,file="parameter_res.txt",col.names=F, row.names=F, sep="\t", quote=F, appen=T)



 