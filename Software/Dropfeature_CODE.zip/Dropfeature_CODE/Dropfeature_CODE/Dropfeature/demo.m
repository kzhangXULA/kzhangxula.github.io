mkdir('./Result');

number_iterations = 100;
number_neurons_input= [1000];
length_vector_number = size(number_neurons_input,2);
learning_rate = [0.001];
length_vector_learning = size(learning_rate,2);
activation_function_name = {'tansig'};
length_vector_act = size(activation_function_name,2);
output_function_name = {'logsig'};
length_vector_out = size(output_function_name,2);
learning_algorithm_name = {'traincgf'};
length_vector_algo = size(learning_algorithm_name,2);

for z = 1:length_vector_algo
    for y = 1:length_vector_out
        for k = 1:length_vector_act
            for j = 1:length_vector_learning
                for i = 1:length_vector_number
                    outdir = sprintf('./Results/neruons_%d_learn_%g_act_', number_neurons_input(1,i),learning_rate(1,j));
                    outdir = strcat(outdir,activation_function_name(1,k));
                    outdir = strcat(outdir,'_out_');
                    outdir = strcat(outdir,output_function_name(1,y));
                    outdir = strcat(outdir,'_algo_');
                    outdir = strcat(outdir,learning_algorithm_name(1,z));
                    s = outdir{1};
                    mkdir(s);

                    trainMseVector1 = [];
                    trainMseVector2 = [];
                    trainMseVector3 = [];
                    trainMseVector4 = [];
                    trainMseVector5 = [];
                    trainMseVector = [];
                    
                    validMseVector1 = [];
                    validMseVector2 = [];
                    validMseVector3 = [];
                    validMseVector4 = [];
                    validMseVector5 = [];
                    validMseVector = [];
                    
                    testMseVector1 = [];
                    testMseVector2 = [];
                    testMseVector3 = [];
                    testMseVector4 = [];
                    testMseVector5 = [];
                    testMseVector = [];

                    auc0Vector1 = [];
                    auc0Vector2 = [];
                    auc0Vector3 = [];
                    auc0Vector4 = [];
                    auc0Vector5 = [];
                    auc0Vector = [];
                    
                    auc1Vector1 = [];
                    auc1Vector2 = [];
                    auc1Vector3 = [];
                    auc1Vector4 = [];
                    auc1Vector5 = [];
                    auc1Vector = [];
                    
                    auc2Vector1 = [];
                    auc2Vector2 = [];
                    auc2Vector3 = [];
                    auc2Vector4 = [];
                    auc2Vector5 = [];
                    auc2Vector = [];
                    
                    auc3Vector1 = [];
                    auc3Vector2 = [];
                    auc3Vector3 = [];
                    auc3Vector4 = [];
                    auc3Vector5 = [];
                    auc3Vector = [];
                    


                    for n = 1:number_iterations
                        fprintf('Running iteration number: %d ...', n);

                        neurons = number_neurons_input(1,i);
                        learn = learning_rate(1,j);
                        act = activation_function_name(1,k);
                        out = output_function_name(1,y);
                        algo = learning_algorithm_name(1,z);
                        [targets, outputs, outputs1, outputs2, outputs3, outputs4, outputs5, MSE_train, MSE_train1, MSE_train2, MSE_train3, MSE_train4, MSE_train5, MSE_valid, MSE_valid1, MSE_valid2, MSE_valid3, MSE_valid4, MSE_valid5, MSE_test, MSE_test1, MSE_test2, MSE_test3, MSE_test4, MSE_test5]=dnn(neurons, learn, act{1}, out{1}, algo{1}, 'learngdm');

                        trainMseVector1(end+1) = MSE_train1;
                        trainMseVector2(end+1) = MSE_train2;
                        trainMseVector3(end+1) = MSE_train3;
                        trainMseVector4(end+1) = MSE_train4;
                        trainMseVector5(end+1) = MSE_train5;
                        trainMseVector(end+1) = MSE_train;
                        
                        validMseVector1(end+1) = MSE_valid1;
                        validMseVector2(end+1) = MSE_valid2;
                        validMseVector3(end+1) = MSE_valid3;
                        validMseVector4(end+1) = MSE_valid4;
                        validMseVector5(end+1) = MSE_valid5;
                        validMseVector(end+1) = MSE_valid;
                        
                        testMseVector1(end+1) = MSE_test1;
                        testMseVector2(end+1) = MSE_test2;
                        testMseVector3(end+1) = MSE_test3;
                        testMseVector4(end+1) = MSE_test4;
                        testMseVector5(end+1) = MSE_test5;
                        testMseVector(end+1) = MSE_test;
                        
                        [X_01,Y_01,T_01,AUC_01] = perfcurve(targets(1,:), outputs1(1,:), 1);
                        [X_02,Y_02,T_02,AUC_02] = perfcurve(targets(1,:), outputs2(1,:), 1);
                        [X_03,Y_03,T_03,AUC_03] = perfcurve(targets(1,:), outputs3(1,:), 1);
                        [X_04,Y_04,T_04,AUC_04] = perfcurve(targets(1,:), outputs4(1,:), 1);
                        [X_05,Y_05,T_05,AUC_05] = perfcurve(targets(1,:), outputs5(1,:), 1);
                        [X_0,Y_0,T_0,AUC_0] = perfcurve(targets(1,:), outputs(1,:), 1);
                        
                        [X_11,Y_11,T_11,AUC_11] = perfcurve(targets(2,:), outputs1(2,:), 1);
                        [X_12,Y_12,T_12,AUC_12] = perfcurve(targets(2,:), outputs2(2,:), 1);
                        [X_13,Y_13,T_13,AUC_13] = perfcurve(targets(2,:), outputs3(2,:), 1);
                        [X_14,Y_14,T_14,AUC_14] = perfcurve(targets(2,:), outputs4(2,:), 1);
                        [X_15,Y_15,T_15,AUC_15] = perfcurve(targets(2,:), outputs5(2,:), 1);
                        [X_1,Y_1,T_1,AUC_1] = perfcurve(targets(2,:), outputs(2,:), 1);
                        
                        [X_21,Y_21,T_21,AUC_21] = perfcurve(targets(3,:), outputs1(3,:), 1);
                        [X_22,Y_22,T_22,AUC_22] = perfcurve(targets(3,:), outputs2(3,:), 1);
                        [X_23,Y_23,T_23,AUC_23] = perfcurve(targets(3,:), outputs3(3,:), 1);
                        [X_24,Y_24,T_24,AUC_24] = perfcurve(targets(3,:), outputs4(3,:), 1);
                        [X_25,Y_25,T_25,AUC_25] = perfcurve(targets(3,:), outputs5(3,:), 1);
                        [X_2,Y_2,T_2,AUC_2] = perfcurve(targets(3,:), outputs(3,:), 1);
                        
                        [X_31,Y_31,T_31,AUC_31] = perfcurve(targets(4,:), outputs1(4,:), 1);
                        [X_32,Y_32,T_32,AUC_32] = perfcurve(targets(4,:), outputs2(4,:), 1);
                        [X_33,Y_33,T_33,AUC_33] = perfcurve(targets(4,:), outputs3(4,:), 1);
                        [X_34,Y_34,T_34,AUC_34] = perfcurve(targets(4,:), outputs4(4,:), 1);
                        [X_35,Y_35,T_35,AUC_35] = perfcurve(targets(4,:), outputs5(4,:), 1);
                        [X_3,Y_3,T_3,AUC_3] = perfcurve(targets(4,:), outputs(4,:), 1);
                      
                        auc0Vector1(end+1) = AUC_01;
                        auc0Vector2(end+1) = AUC_02;
                        auc0Vector3(end+1) = AUC_03;
                        auc0Vector4(end+1) = AUC_04;
                        auc0Vector5(end+1) = AUC_05;
                        auc0Vector(end+1) = AUC_0;
                        
                        auc1Vector1(end+1) = AUC_11;
                        auc1Vector2(end+1) = AUC_12;
                        auc1Vector3(end+1) = AUC_13;
                        auc1Vector4(end+1) = AUC_14;
                        auc1Vector5(end+1) = AUC_15;
                        auc1Vector(end+1) = AUC_1;
                        
                        auc2Vector1(end+1) = AUC_21;
                        auc2Vector2(end+1) = AUC_22;
                        auc2Vector3(end+1) = AUC_23;
                        auc2Vector4(end+1) = AUC_24;
                        auc2Vector5(end+1) = AUC_25;
                        auc2Vector(end+1) = AUC_2;
                        
                        auc3Vector1(end+1) = AUC_31;
                        auc3Vector2(end+1) = AUC_32;
                        auc3Vector3(end+1) = AUC_33;
                        auc3Vector4(end+1) = AUC_34;
                        auc3Vector5(end+1) = AUC_35;
                        auc3Vector(end+1) = AUC_3;
                        
                                            
                        AUC_box = [AUC_01 AUC_02 AUC_03 AUC_04 AUC_05;
                        AUC_11 AUC_12 AUC_13 AUC_14 AUC_15;
                        AUC_21 AUC_22 AUC_23 AUC_24 AUC_25;
                        AUC_31 AUC_32 AUC_33 AUC_34 AUC_35;];
                        
                        
                        iteration = sprintf('/Iteration%d',n);
                        outdir2 = strcat(outdir,iteration);
                        mkdir(outdir2{1});

                                             
                        a1 = figure('Name', 'Confusion Matriz', 'Visible', 'Off');
                        plotconfusion(targets, outputs1);
                        print(strcat(outdir2{1}, '/Confusion1') , '-dtiff');

                        a2 = figure('Name', 'Confusion Matriz', 'Visible', 'Off');
                        plotconfusion(targets, outputs2);
                        print(strcat(outdir2{1}, '/Confusion2') , '-dtiff');
                        
                        a3 = figure('Name', 'Confusion Matriz', 'Visible', 'Off');
                        plotconfusion(targets, outputs3);
                        print(strcat(outdir2{1}, '/Confusion3') , '-dtiff');
                        
                        a4 = figure('Name', 'Confusion Matriz', 'Visible', 'Off');
                        plotconfusion(targets, outputs4);
                        print(strcat(outdir2{1}, '/Confusion4') , '-dtiff');
                        
                        a5 = figure('Name', 'Confusion Matriz', 'Visible', 'Off');
                        plotconfusion(targets, outputs5);
                        print(strcat(outdir2{1}, '/Confusion5') , '-dtiff');
                        
                                              
                        a = figure('Name', 'Confusion Matriz', 'Visible', 'Off');
                        plotconfusion(targets, outputs);
                        print(strcat(outdir2{1}, '/Confusion') , '-dtiff');
                        
                        b1 = figure('Name', 'ROC Curve', 'visible', 'off');
                        plotroc(targets, outputs1);
                        print(strcat(outdir2{1}, '/ROC1'), '-dtiff');
                        
                        b2 = figure('Name', 'ROC Curve', 'visible', 'off');
                        plotroc(targets, outputs2);
                        print(strcat(outdir2{1}, '/ROC2'), '-dtiff');
                        
                        b3 = figure('Name', 'ROC Curve', 'visible', 'off');
                        plotroc(targets, outputs3);
                        print(strcat(outdir2{1}, '/ROC3'), '-dtiff');
                        
                        b4 = figure('Name', 'ROC Curve', 'visible', 'off');
                        plotroc(targets, outputs4);
                        print(strcat(outdir2{1}, '/ROC4'), '-dtiff');
                        
                        b5 = figure('Name', 'ROC Curve', 'visible', 'off');
                        plotroc(targets, outputs5);
                        print(strcat(outdir2{1}, '/ROC5'), '-dtiff');
                        
                        b = figure('Name', 'ROC Curve', 'visible', 'off');
                        plotroc(targets, outputs);
                        print(strcat(outdir2{1}, '/ROC'), '-dtiff');
                        
                        
                        
                        c = figure('units','normalized','outerposition',[0 0 1 1])
                        boxplot(AUC_box);
                        set(gca,'xticklabel',{'1' '2' '3' '4' '5'})
                        xlabel('Different Validations');
                        ylabel('AUC-measure Statistics');
                        title('Five-fold Cross Validation using AUC');
                        print(strcat(outdir2{1}, '/BOX1'), '-dtiff');
                        
                        
                        
                        d = figure('units','normalized','outerposition',[0 0 1 1])
                        boxplot(AUC_box');
                        set(gca,'xticklabel',{'1' '2' '3' '4'})
                        xlabel('Different Classes');
                        ylabel('AUC-measure Statistics');
                        title('Five-fold Cross Validation using AUC');
                        print(strcat(outdir2{1}, '/BOX2'), '-dtiff');

                        delete(a1);
                        delete(a2);
                        delete(a3);
                        delete(a4);
                        delete(a5);
                        delete(a);
                        
                        delete(b1);
                        delete(b2);
                        delete(b3);
                        delete(b4);
                        delete(b5);
                        delete(b);
                        
                        delete(c);
                        delete(d);
                        
                        
                      
                        
                        
                       
                    end

                    meanTrainMse1 = mean(trainMseVector1);
                    meanValidMse1 = mean(validMseVector1);
                    meanTestMse1 = mean(testMseVector1);
                    meanAuc01 = mean(auc0Vector1);
                    meanAuc11 = mean(auc1Vector1);
                    meanAuc21 = mean(auc2Vector1);
                    meanAuc31 = mean(auc3Vector1);
              
                    
                    meanTrainMse2 = mean(trainMseVector2);
                    meanValidMse2 = mean(validMseVector2);
                    meanTestMse2 = mean(testMseVector2);
                    meanAuc02 = mean(auc0Vector2);
                    meanAuc12 = mean(auc1Vector2);
                    meanAuc22 = mean(auc2Vector2);
                    meanAuc32 = mean(auc3Vector2);

                    
                    meanTrainMse3 = mean(trainMseVector3);
                    meanValidMse3 = mean(validMseVector3);
                    meanTestMse3 = mean(testMseVector3);
                    meanAuc03 = mean(auc0Vector3);
                    meanAuc13 = mean(auc1Vector3);
                    meanAuc23 = mean(auc2Vector3);
                    meanAuc33 = mean(auc3Vector3);

                    
                    meanTrainMse4 = mean(trainMseVector4);
                    meanValidMse4 = mean(validMseVector4);
                    meanTestMse4 = mean(testMseVector4);
                    meanAuc04 = mean(auc0Vector4);
                    meanAuc14 = mean(auc1Vector4);
                    meanAuc24 = mean(auc2Vector4);
                    meanAuc34 = mean(auc3Vector4);

                    
                    meanTrainMse5 = mean(trainMseVector5);
                    meanValidMse5 = mean(validMseVector5);
                    meanTestMse5 = mean(testMseVector5);
                    meanAuc05 = mean(auc0Vector5);
                    meanAuc15 = mean(auc1Vector5);
                    meanAuc25 = mean(auc2Vector5);
                    meanAuc35 = mean(auc3Vector5);

                    
                    
                    meanTrainMse = mean(trainMseVector);
                    meanValidMse = mean(validMseVector);
                    meanTestMse = mean(testMseVector);
                    meanAuc0 = mean(auc0Vector);
                    meanAuc1 = mean(auc1Vector);
                    meanAuc2 = mean(auc2Vector);
                    meanAuc3 = mean(auc3Vector);

                    

                    fileID = fopen(strcat(outdir{1}, '/results.txt'), 'w');
                    fprintf(fileID, 'Results counting %d iterations... \r\n\r\n', n);

                    str = mat2str(trainMseVector1);
                    fprintf(fileID, '%s\r\n' ,str);
                    fprintf(fileID, 'Mean MSE of the training set: %6.5f \r\n',meanTrainMse1);
                    fprintf(fileID, 'MSE (standard deviation) of training set: %6.5f \r\n\r\n',std(trainMseVector1));
                    
      
                    str = mat2str(trainMseVector2);
                    fprintf(fileID, '%s\r\n' ,str);
                    fprintf(fileID, 'Mean MSE of the training set: %6.5f \r\n',meanTrainMse2);
                    fprintf(fileID, 'MSE (standard deviation) of training set: %6.5f \r\n\r\n',std(trainMseVector2));
                    
                    str = mat2str(trainMseVector3);
                    fprintf(fileID, '%s\r\n' ,str);
                    fprintf(fileID, 'Mean MSE of the training set: %6.5f \r\n',meanTrainMse3);
                    fprintf(fileID, 'MSE (standard deviation) of training set: %6.5f \r\n\r\n',std(trainMseVector3));
                    
                    str = mat2str(trainMseVector4);
                    fprintf(fileID, '%s\r\n' ,str);
                    fprintf(fileID, 'Mean MSE of the training set: %6.5f \r\n',meanTrainMse4);
                    fprintf(fileID, 'MSE (standard deviation) of training set: %6.5f \r\n\r\n',std(trainMseVector4));
                    
                    str = mat2str(trainMseVector5);
                    fprintf(fileID, '%s\r\n' ,str);
                    fprintf(fileID, 'Mean MSE of the training set: %6.5f \r\n',meanTrainMse5);
                    fprintf(fileID, 'MSE (standard deviation) of training set: %6.5f \r\n\r\n',std(trainMseVector5));
                    
                    str = mat2str(trainMseVector);
                    fprintf(fileID, '%s\r\n' ,str);
                    fprintf(fileID, 'Mean MSE of the training set: %6.5f \r\n',meanTrainMse);
                    fprintf(fileID, 'MSE (standard deviation) of training set: %6.5f \r\n\r\n',std(trainMseVector));
                    

                                  
                    str = mat2str(validMseVector1);
                    fprintf(fileID, '%s\r\n' ,str);
                    fprintf(fileID, 'Mean MSE of the validation set: %6.5f \r\n',meanValidMse1);
                    fprintf(fileID, 'MSE (standard deviation) of validation set: %6.5f \r\n\r\n',std(validMseVector1));
                    
                    str = mat2str(validMseVector2);
                    fprintf(fileID, '%s\r\n' ,str);
                    fprintf(fileID, 'Mean MSE of the validation set: %6.5f \r\n',meanValidMse2);
                    fprintf(fileID, 'MSE (standard deviation) of validation set: %6.5f \r\n\r\n',std(validMseVector2));
                    
                    str = mat2str(validMseVector3);
                    fprintf(fileID, '%s\r\n' ,str);
                    fprintf(fileID, 'Mean MSE of the validation set: %6.5f \r\n',meanValidMse3);
                    fprintf(fileID, 'MSE (standard deviation) of validation set: %6.5f \r\n\r\n',std(validMseVector3));
                    
                    str = mat2str(validMseVector4);
                    fprintf(fileID, '%s\r\n' ,str);
                    fprintf(fileID, 'Mean MSE of the validation set: %6.5f \r\n',meanValidMse4);
                    fprintf(fileID, 'MSE (standard deviation) of validation set: %6.5f \r\n\r\n',std(validMseVector4));
                    
                    str = mat2str(validMseVector5);
                    fprintf(fileID, '%s\r\n' ,str);
                    fprintf(fileID, 'Mean MSE of the validation set: %6.5f \r\n',meanValidMse5);
                    fprintf(fileID, 'MSE (standard deviation) of validation set: %6.5f \r\n\r\n',std(validMseVector5));
                    
                    str = mat2str(validMseVector);
                    fprintf(fileID, '%s\r\n' ,str);
                    fprintf(fileID, 'Mean MSE of the validation set: %6.5f \r\n',meanValidMse);
                    fprintf(fileID, 'MSE (standard deviation) of validation set: %6.5f \r\n\r\n',std(validMseVector));
                    
                    str = mat2str(testMseVector1);
                    fprintf(fileID, '%s\r\n' ,str);
                    fprintf(fileID, 'Mean MSE of the test set: %6.5f \r\n',meanTestMse1);
                    fprintf(fileID, 'MSE (standard deviation) of test set: %6.5f \r\n\r\n',std(testMseVector1));               
                    
                    str = mat2str(testMseVector2);
                    fprintf(fileID, '%s\r\n' ,str);
                    fprintf(fileID, 'Mean MSE of the test set: %6.5f \r\n',meanTestMse2);
                    fprintf(fileID, 'MSE (standard deviation) of test set: %6.5f \r\n\r\n',std(testMseVector2));                 
                    
                    
                    str = mat2str(testMseVector3);
                    fprintf(fileID, '%s\r\n' ,str);
                    fprintf(fileID, 'Mean MSE of the test set: %6.5f \r\n',meanTestMse3);
                    fprintf(fileID, 'MSE (standard deviation) of test set: %6.5f \r\n\r\n',std(testMseVector3));                 
                    
                    str = mat2str(testMseVector4);
                    fprintf(fileID, '%s\r\n' ,str);
                    fprintf(fileID, 'Mean MSE of the test set: %6.5f \r\n',meanTestMse4);
                    fprintf(fileID, 'MSE (standard deviation) of test set: %6.5f \r\n\r\n',std(testMseVector4));
                    
                    str = mat2str(testMseVector5);
                    fprintf(fileID, '%s\r\n' ,str);
                    fprintf(fileID, 'Mean MSE of the test set: %6.5f \r\n',meanTestMse5);
                    fprintf(fileID, 'MSE (standard deviation) of test set: %6.5f \r\n\r\n',std(testMseVector5));
                    

                    str = mat2str(testMseVector);
                    fprintf(fileID, '%s\r\n' ,str);
                    fprintf(fileID, 'Mean MSE of the test set: %6.5f \r\n',meanTestMse);
                    fprintf(fileID, 'MSE (standard deviation) of test set: %6.5f \r\n\r\n',std(testMseVector));

                                       
                    
                    
                    
                    str = mat2str(auc0Vector1);
                    fprintf(fileID, 'AUCs-01: %s\r\n' ,str);
                    str = mat2str(auc1Vector1);
                    fprintf(fileID, 'AUCs-11: %s\r\n' ,str);
                    str = mat2str(auc2Vector1);
                    fprintf(fileID, 'AUCs-21: %s\r\n' ,str);
                    str = mat2str(auc3Vector1);
                    fprintf(fileID, 'AUCs-31: %s\r\n' ,str);

                    
                    str = mat2str(auc0Vector2);
                    fprintf(fileID, 'AUCs-02: %s\r\n' ,str);
                    str = mat2str(auc1Vector2);
                    fprintf(fileID, 'AUCs-12: %s\r\n' ,str);
                    str = mat2str(auc2Vector2);
                    fprintf(fileID, 'AUCs-22: %s\r\n' ,str);
                    str = mat2str(auc3Vector2);
                    fprintf(fileID, 'AUCs-32: %s\r\n' ,str);

                    
                    str = mat2str(auc0Vector3);
                    fprintf(fileID, 'AUCs-03: %s\r\n' ,str);
                    str = mat2str(auc1Vector3);
                    fprintf(fileID, 'AUCs-13: %s\r\n' ,str);
                    str = mat2str(auc2Vector3);
                    fprintf(fileID, 'AUCs-23: %s\r\n' ,str);
                    str = mat2str(auc3Vector3);
                    fprintf(fileID, 'AUCs-33: %s\r\n' ,str);

                    
                    
                    str = mat2str(auc0Vector4);
                    fprintf(fileID, 'AUCs-04: %s\r\n' ,str);
                    str = mat2str(auc1Vector4);
                    fprintf(fileID, 'AUCs-14: %s\r\n' ,str);
                    str = mat2str(auc2Vector4);
                    fprintf(fileID, 'AUCs-24: %s\r\n' ,str);
                    str = mat2str(auc3Vector4);
                    fprintf(fileID, 'AUCs-34: %s\r\n' ,str);

                    
                    str = mat2str(auc0Vector5);
                    fprintf(fileID, 'AUCs-05: %s\r\n' ,str);
                    str = mat2str(auc1Vector5);
                    fprintf(fileID, 'AUCs-15: %s\r\n' ,str);
                    str = mat2str(auc2Vector5);
                    fprintf(fileID, 'AUCs-25: %s\r\n' ,str);
                    str = mat2str(auc3Vector5);
                    fprintf(fileID, 'AUCs-35: %s\r\n' ,str);

                    
                    str = mat2str(auc0Vector);
                    fprintf(fileID, 'AUCs-0: %s\r\n' ,str);
                    str = mat2str(auc1Vector);
                    fprintf(fileID, 'AUCs-1: %s\r\n' ,str);
                    str = mat2str(auc2Vector);
                    fprintf(fileID, 'AUCs-2: %s\r\n' ,str);
                    str = mat2str(auc3Vector);
                    fprintf(fileID, 'AUCs-3: %s\r\n' ,str);


                    fprintf(fileID, 'Mean of AUC1 for both classes:\r\nAUC-01: %0.10f\r\nAUC-11: %0.10f\r\nAUC-21: %0.10f\r\nAUC-31: %0.10f \r\n', meanAuc01, meanAuc11, meanAuc21, meanAuc31);
                    fprintf(fileID, 'Mean of AUC2 for both classes:\r\nAUC-02: %0.10f\r\nAUC-12: %0.10f\r\nAUC-22: %0.10f\r\nAUC-32: %0.10f \r\n', meanAuc02, meanAuc12, meanAuc22, meanAuc32);
                    fprintf(fileID, 'Mean of AUC3 for both classes:\r\nAUC-03: %0.10f\r\nAUC-13: %0.10f\r\nAUC-23: %0.10f\r\nAUC-33: %0.10f \r\n', meanAuc03, meanAuc13, meanAuc23, meanAuc33);
                    fprintf(fileID, 'Mean of AUC4 for both classes:\r\nAUC-04: %0.10f\r\nAUC-14: %0.10f\r\nAUC-24: %0.10f\r\nAUC-34: %0.10f \r\n', meanAuc04, meanAuc14, meanAuc24, meanAuc34);
                    fprintf(fileID, 'Mean of AUC5 for both classes:\r\nAUC-05: %0.10f\r\nAUC-15: %0.10f\r\nAUC-25: %0.10f\r\nAUC-35: %0.10f \r\n', meanAuc05, meanAuc15, meanAuc25, meanAuc35);
                    fprintf(fileID, 'Mean of AUC for both classes:\r\nAUC-0: %0.10f\r\nAUC-1: %0.10f\r\nAUC-2: %0.10f\r\nAUC-3: %0.10f \r\n', meanAuc0, meanAuc1, meanAuc2, meanAuc3);
                    fprintf(fileID, 'Standard deviation of AUC1 for both classes:\r\nAUC-01: %0.10f\r\nAUC-11: %0.10f\r\nAUC-21: %0.10f\r\nAUC-31: %0.10f \r\n', std(auc0Vector1), std(auc1Vector1), std(auc2Vector1), std(auc3Vector1));
                    fprintf(fileID, 'Standard deviation of AUC2 for both classes:\r\nAUC-02: %0.10f\r\nAUC-12: %0.10f\r\nAUC-22: %0.10f\r\nAUC-32: %0.10f \r\n', std(auc0Vector2), std(auc1Vector2), std(auc2Vector2), std(auc3Vector2));
                    fprintf(fileID, 'Standard deviation of AUC3 for both classes:\r\nAUC-03: %0.10f\r\nAUC-13: %0.10f\r\nAUC-23: %0.10f\r\nAUC-33: %0.10f \r\n', std(auc0Vector3), std(auc1Vector3), std(auc2Vector3), std(auc3Vector3));
                    fprintf(fileID, 'Standard deviation of AUC4 for both classes:\r\nAUC-04: %0.10f\r\nAUC-14: %0.10f\r\nAUC-24: %0.10f\r\nAUC-34: %0.10f \r\n', std(auc0Vector4), std(auc1Vector4), std(auc2Vector4), std(auc3Vector4));
                    fprintf(fileID, 'Standard deviation of AUC5 for both classes:\r\nAUC-05: %0.10f\r\nAUC-15: %0.10f\r\nAUC-25: %0.10f\r\nAUC-35: %0.10f \r\n', std(auc0Vector5), std(auc1Vector5), std(auc2Vector5), std(auc3Vector5));
                    fprintf(fileID, 'Standard deviation of AUC for both classes:\r\nAUC-0: %0.10f\r\nAUC-1: %0.10f\r\nAUC-2: %0.10f\r\nAUC-3: %0.10f \r\n', std(auc0Vector), std(auc1Vector), std(auc2Vector), std(auc3Vector));
                    fclose(fileID);

                end
            end
        end
    end
end
