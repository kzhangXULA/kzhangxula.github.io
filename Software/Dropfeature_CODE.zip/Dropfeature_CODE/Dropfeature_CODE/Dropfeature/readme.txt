Copyright: Zhong Chen and Kun Zhang
If you use code in this package please cite
Chen, Z., Zhang, W., Deng, H. and Zhang, K., 2021. Effective Cancer Subtype and Stage Prediction via Dropfeature-DNNs. IEEE/ACM Transactions on Computational Biology and Bioinformatics.

Required software
Matlab
Deep learning matlab toolbox: https://github.com/rasmusbergpalm/DeepLearnToolbox

Run demo.m
