
function [targets, outputs, outputs1, outputs2, outputs3, outputs4, outputs5, MSE_train, MSE_train1, MSE_train2, MSE_train3, MSE_train4, MSE_train5, MSE_valid, MSE_valid1, MSE_valid2, MSE_valid3, MSE_valid4, MSE_valid5, MSE_test, MSE_test1, MSE_test2, MSE_test3, MSE_test4, MSE_test5]=dnn(num_intermediate_nodes, learning_rate, activation_function_name, output_function_name, learning_algorithm_name, weigth_algorithm_name)
    echo on

    numEntradas   = 500;                         
    numEscondidos = num_intermediate_nodes;        
    numSaidas     = 4;                              
    numTr         = 200;                          
    numVal        = 50;                           
    numTeste      = 81;                            
    
    nHid2 = 1000;
    nHid3 = 100;
    nHid4 = 100;
 

    echo off

    load('./Datasets/TCGA_500_data.mat');
    
    % 5-fold cross-validation
    genexp_ALL= [traindata;validationdata];
    
    traindata = [];
    validationdata = [];
    
    indices = crossvalind('Kfold', 250, 5);
    for i = 1:5
    test_indice = (indices == i);
    train_indice = ~test_indice;
    traindata = [traindata; genexp_ALL(train_indice, :)];
    validationdata = [validationdata; genexp_ALL(test_indice, :)];
    end
    
    entradasTreinamento1 = traindata(1:numTr,1:numEntradas)';
    saidasTreinamento1   = traindata(1:numTr,(numEntradas + 1):(numEntradas + numSaidas))';


    entradasValidacao1   = validationdata(1:numVal,1:numEntradas)';
    saidasValidacao1     = validationdata(1:numVal,(numEntradas + 1):(numEntradas + numSaidas))';
    

    entradasTreinamento2 = traindata((numTr+1):(2*numTr),1:numEntradas)';
    saidasTreinamento2   = traindata((numTr+1):(2*numTr),(numEntradas + 1):(numEntradas + numSaidas))';


    entradasValidacao2   = validationdata((numVal+1):(2*numVal),1:numEntradas)';
    saidasValidacao2     = validationdata((numVal+1):(2*numVal),(numEntradas + 1):(numEntradas + numSaidas))';
    

    entradasTreinamento3 = traindata((2*numTr+1):(3*numTr),1:numEntradas)';
    saidasTreinamento3   = traindata((2*numTr+1):(3*numTr),(numEntradas + 1):(numEntradas + numSaidas))';
   
    entradasValidacao3   = validationdata((2*numVal+1):(3*numVal),1:numEntradas)';
    saidasValidacao3     = validationdata((2*numVal+1):(3*numVal),(numEntradas + 1):(numEntradas + numSaidas))';
   
    

    entradasTreinamento4 = traindata((3*numTr+1):(4*numTr),1:numEntradas)';
    saidasTreinamento4   = traindata((3*numTr+1):(4*numTr),(numEntradas + 1):(numEntradas + numSaidas))';
   
    entradasValidacao4   = validationdata((3*numVal+1):(4*numVal),1:numEntradas)';
    saidasValidacao4     = validationdata((3*numVal+1):(4*numVal),(numEntradas + 1):(numEntradas + numSaidas))';
    


    entradasTreinamento5 = traindata((4*numTr+1):(5*numTr),1:numEntradas)';
    saidasTreinamento5   = traindata((4*numTr+1):(5*numTr),(numEntradas + 1):(numEntradas + numSaidas))';
   
    entradasValidacao5   = validationdata((4*numVal+1):(5*numVal),1:numEntradas)';
    saidasValidacao5     = validationdata((4*numVal+1):(5*numVal),(numEntradas + 1):(numEntradas + numSaidas))';    
    
    

    entradasTeste       = testdata(1:numTeste,1:numEntradas)';
    saidasTeste         = testdata(1:numTeste,(numEntradas + 1):(numEntradas + numSaidas))';


    for entrada = 1 : numEntradas;  % Creates 'matrizFaixa', which has 'numEntradas' lines, each one equal to [0 1].
         matrizFaixa(entrada,:) = [0 1];
    end

    rede = newff(matrizFaixa,[numEscondidos, nHid2, nHid3, nHid4, numSaidas],{activation_function_name, activation_function_name, activation_function_name, activation_function_name, output_function_name}, learning_algorithm_name, weigth_algorithm_name,'mse');

    rede = init(rede);
    echo on

    rede.trainParam.epochs   = 10000;             
    rede.trainParam.lr       = learning_rate;    
    rede.trainParam.goal     = 0;                
    rede.trainParam.max_fail = 20;                
    rede.trainParam.min_grad = 0;                 
    rede.trainParam.show     = 10;                
    rede.trainParam.time     = inf;               
    echo off
    
    fprintf('\nTraining ...\n')

    conjuntoValidacao1.P = entradasValidacao1; 
    conjuntoValidacao1.T = saidasValidacao1;   
    
    conjuntoValidacao2.P = entradasValidacao2;
    conjuntoValidacao2.T = saidasValidacao2;  
    
    conjuntoValidacao3.P = entradasValidacao3;
    conjuntoValidacao3.T = saidasValidacao3;   

    conjuntoValidacao4.P = entradasValidacao4;
    conjuntoValidacao4.T = saidasValidacao4;  
    
    conjuntoValidacao5.P = entradasValidacao5; 
    conjuntoValidacao5.T = saidasValidacao5;   

    %  Training the net
    [redeNova1,desempenho1,saidasRede1,erros1] = train(rede,entradasTreinamento1,saidasTreinamento1,[],[],conjuntoValidacao1);
    [redeNova2,desempenho2,saidasRede2,erros2] = train(rede,entradasTreinamento2,saidasTreinamento2,[],[],conjuntoValidacao2);
    [redeNova3,desempenho3,saidasRede3,erros3] = train(rede,entradasTreinamento3,saidasTreinamento3,[],[],conjuntoValidacao3);
    [redeNova4,desempenho4,saidasRede4,erros4] = train(rede,entradasTreinamento4,saidasTreinamento4,[],[],conjuntoValidacao4);
    [redeNova5,desempenho5,saidasRede5,erros5] = train(rede,entradasTreinamento5,saidasTreinamento5,[],[],conjuntoValidacao5);
    
    fprintf('\nTesting ...\n');


    [saidasRedeTeste1,Pf1,Af1,errosTeste1,desempenhoTeste1] = privatesim(redeNova1,entradasTeste,[],[],saidasTeste);
    [maiorSaidaRede1, nodoVencedorRede1] = max (saidasRedeTeste1);

    [saidasRedeTeste2,Pf2,Af2,errosTeste2,desempenhoTeste2] = privatesim(redeNova2,entradasTeste,[],[],saidasTeste);
    [maiorSaidaRede2, nodoVencedorRede2] = max (saidasRedeTeste2);    
    
    [saidasRedeTeste3,Pf3,Af3,errosTeste3,desempenhoTeste3] = privatesim(redeNova3,entradasTeste,[],[],saidasTeste);
    [maiorSaidaRede3, nodoVencedorRede3] = max (saidasRedeTeste3);
    
    [saidasRedeTeste4,Pf4,Af4,errosTeste4,desempenhoTeste4] = privatesim(redeNova4,entradasTeste,[],[],saidasTeste);
    [maiorSaidaRede4, nodoVencedorRede4] = max (saidasRedeTeste4); 
    
    [saidasRedeTeste5,Pf5,Af5,errosTeste5,desempenhoTeste5] = privatesim(redeNova5,entradasTeste,[],[],saidasTeste);
    [maiorSaidaRede5, nodoVencedorRede5] = max (saidasRedeTeste5);    
    
    [maiorSaidaDesejada, nodoVencedorDesejado] = max (saidasTeste);

    classificacoesErradas=0;
    classificacoesErradas1 = 0;
    classificacoesErradas2 = 0;
    classificacoesErradas3 = 0;
    classificacoesErradas4 = 0;
    classificacoesErradas5 = 0;
    
    for padrao = 1 : numTeste
        if nodoVencedorRede1(padrao) ~= nodoVencedorDesejado(padrao)
            classificacoesErradas1 = classificacoesErradas1 + 1;
        end
        
        if nodoVencedorRede2(padrao) ~= nodoVencedorDesejado(padrao)
            classificacoesErradas2 = classificacoesErradas2 + 1;
        end
        
        if nodoVencedorRede3(padrao) ~= nodoVencedorDesejado(padrao)
            classificacoesErradas3 = classificacoesErradas3 + 1;
        end
        
        if nodoVencedorRede4(padrao) ~= nodoVencedorDesejado(padrao)
            classificacoesErradas4 = classificacoesErradas4 + 1;
        end
        
        if nodoVencedorRede5(padrao) ~= nodoVencedorDesejado(padrao)
            classificacoesErradas5 = classificacoesErradas5 + 1;
        end
        
    end
    erroClassifTeste1 = 100 * (classificacoesErradas1/numTeste);
    erroClassifTeste2 = 100 * (classificacoesErradas2/numTeste);
    erroClassifTeste3 = 100 * (classificacoesErradas3/numTeste);
    erroClassifTeste4 = 100 * (classificacoesErradas4/numTeste);
    erroClassifTeste5 = 100 * (classificacoesErradas5/numTeste);
    erroClassifTeste=(erroClassifTeste1+erroClassifTeste2+erroClassifTeste3+erroClassifTeste4+erroClassifTeste5)/5;
    
    fprintf('Classification error (1st-validation) for test set: %6.5f\n',erroClassifTeste1);
    fprintf('Classification error (2ed-validation) for test set: %6.5f\n',erroClassifTeste2);
    fprintf('Classification error (3rd-validation) for test set: %6.5f\n',erroClassifTeste3);
    fprintf('Classification error (4th-validation) for test set: %6.5f\n',erroClassifTeste4);
    fprintf('Classification error (5th-validation) for test set: %6.5f\n',erroClassifTeste5);
    fprintf('Classification error (average) for test set: %6.5f\n',erroClassifTeste);
    
    targets = saidasTeste;
    
    outputs1 = saidasRedeTeste1;
    MSE_train1 = desempenho1.perf(length(desempenho1.perf));
    MSE_valid1 = desempenho1.vperf(length(desempenho1.vperf));
    MSE_test1 = desempenhoTeste1;
    
    outputs2 = saidasRedeTeste2;
    MSE_train2 = desempenho2.perf(length(desempenho2.perf));
    MSE_valid2 = desempenho2.vperf(length(desempenho2.vperf));
    MSE_test2 = desempenhoTeste2;
    
    outputs3 = saidasRedeTeste3;
    MSE_train3 = desempenho3.perf(length(desempenho3.perf));
    MSE_valid3 = desempenho3.vperf(length(desempenho3.vperf));
    MSE_test3 = desempenhoTeste3;
    
    outputs4 = saidasRedeTeste4;
    MSE_train4 = desempenho4.perf(length(desempenho4.perf));
    MSE_valid4 = desempenho4.vperf(length(desempenho4.vperf));
    MSE_test4 = desempenhoTeste4;
    
    outputs5 = saidasRedeTeste5;
    MSE_train5 = desempenho5.perf(length(desempenho5.perf));
    MSE_valid5 = desempenho5.vperf(length(desempenho5.vperf));
    MSE_test5 = desempenhoTeste5;
    
    outputs = (outputs1+outputs2+outputs3+outputs4+outputs5)/5;

    MSE_train = (MSE_train1+MSE_train2+MSE_train3+MSE_train4+MSE_train5)/5;
    MSE_valid =(MSE_valid1+MSE_valid2+MSE_valid3+MSE_valid4+MSE_valid5)/5;
    MSE_test = (MSE_test1+MSE_test2+MSE_test3+MSE_test4+MSE_test5)/5;
    
    return;

end
