function [Y,Xf,Af,E,perf]=sim(net,varargin)

if nargin < 1, error(message('nnet:Args:NotEnough')); end
if ~isa(net,'network')
  error('nnet:train:arguments','First argument is not a neural network.');
end
net = struct(net);
net.trainFcn = ''; 
[~,zeroDelayLoop] = nn.layer_order(net);
 if zeroDelayLoop, error(message('nnet:NNet:ZeroDelayLoop')); end
 
if ~isempty(varargin) && isstruct(varargin{end}) && isfield(varargin{end},'name')
  calcMode = nncalc.defaultMode(net,varargin{end}); varargin(end) = [];
  calcMode.options = nnet.options.calc.defaults;
  calcMode.options.showResources = 'yes';
  
else
  [varargin,nameValuePairs] = nnet.arguments.extractNameValuePairs(varargin);
  [calcMode,err] = nncalc.options2Mode(net,nameValuePairs);
  if ~isempty(err), error('nnet:train:arguments',err); end
end
problem = calcMode.netCheck(net,calcMode.hints,false,false);
if ~isempty(problem), error(problem); end


nargs = numel(varargin);
if nargs >= 1
  isComposite = isa(varargin{1},'Composite');
else
  isComposite = false;
end
for i=2:nargs
  if isComposite ~= isa(varargin{i},'Composite')
    error('nnet:sim:Composite','Data values must be all Composite or not.');
  end
end

if nargs >= 1
  isGPUArray = isa(varargin{1},'gpuArray');
else
  isGPUArray = false;
end
for i=2:nargs
  vi = varargin{i};
  if ~isempty(vi) && (isGPUArray ~= isa(vi,'gpuArray')) 
    error('nnet:sim:Composite','Data values must be all gpuArray or not.');
  end
end

if isComposite
  emptyCell = Composite;
  oneCell = Composite;
  for i=1:numel(emptyCell)
    emptyCell{i} = {};
    oneCell{i} = {1};
  end
else
  emptyCell = {};
  oneCell = {1};
end
if (nargs < 1), X = emptyCell; else X = varargin{1}; end
if (nargs < 2), Xi = emptyCell; else Xi = varargin{2}; end
if (nargs < 3), Ai = emptyCell; else Ai = varargin{3}; end
if (nargs < 4), T = emptyCell; else T = varargin{4}; end
if (nargs < 5) || isempty(varargin{5}), EW=oneCell; else EW=varargin{5}; end
if isComposite
  for i=1:numel(X)
    if ~exist(X,i), X{i} = {}; end
    if ~exist(T,i), T{i} = {}; end
    if ~exist(Xi,i), Xi{i} = {}; end
    if ~exist(Ai,i), Ai{i} = {}; end
    if ~exist(EW,i), EW{i} = {1}; end
  end
end

if isComposite
  spmd, xMatrix = ~iscell(X) && ~isa(X,'gpuArray'); end
elseif isGPUArray
  xMatrix = false;
else
  xMatrix = ~iscell(X);
end


if ~isComposite && ~isGPUArray
  xMatrix = ~iscell(X);
  if (net.numInputs == 0)
    if xMatrix && isscalar(X)
      X = {zeros(0,X)};
    elseif ~xMatrix && isscalar(X) && isscalar(X{1})
      X = cell(1,X{1});
    elseif xMatrix && (ndims(X)==2) && all(size(X)==[1 2])
      Q = X(1);
      TS = X(2);
      X = cell(1,TS);
      for i=1:TS,X{i} = zeros(1,Q); end
      xMatrix = false;
    elseif ~xMatrix && (ndims(X)==2) && all(size(X)==[1 2]) ...
        && isscalar(X{1}) && isscalar(X{2})
      Q = X{1}; TS = X{2};
      X = cell(1,TS);
      for i=1:TS,X{i} = zeros(1,Q); end
      xMatrix = false;
    end
  end
  X = nntype.data('format',X,'Inputs');
end

if ~isComposite
  tMatrix = ~iscell(T);
  if ~isempty(T), T = nntype.data('format',T,'Targets'); end
end

if isComposite
  spmd
    [data,err] = simData(net,X,Xi,Ai,T,EW);
    if ~isempty(regexp(err,'^nnet:','once')), error(message(err)), end
    if ~isempty(err), nnerr.throw(err), end
  end
else
  [data,err] = simData(net,X,Xi,Ai,T,EW);
  if ~isempty(regexp(err,'^nnet:','once')), error(message(err)), end
  if ~isempty(err), nnerr.throw(err), end
end

[calcLib,calcNet,net,resourceText] = nncalc_setup(calcMode,net,data);
if ~isempty(resourceText)
  disp(' ')
  disp('Computing Resources:')
  nntext.disp(resourceText)
  disp(' ')
end
isParallel = isa(calcLib,'Composite');
doAf = (nargout == 3);
doXf = (nargout >= 2);

if isParallel
  spmd
    [Y,Af] = simPerWorker(calcLib,calcNet,doAf);
    if isComposite
      if doXf, Xf = getXf(net,data); end
      if (xMatrix)
        if isempty(Y), Y = zeros(sum(nn.output_sizes(net)),data.Q); else Y = cell2mat(Y); end
      end
    end
    if (labindex == 1), mainWorkerInd = calcLib.mainWorkerInd; end
  end
  if ~isComposite
    mainWorkerInd = mainWorkerInd{1};
    Y = Y{mainWorkerInd};
    if xMatrix
      if isempty(Y), Y = zeros(sum(nn.output_sizes(net)),data.Q); else Y = cell2mat(Y); end
    end
    if doXf, Xf = getXf(net,data); end
    if doAf, Af = Af{mainWorkerInd}; end
  end
  
else
  [Y,Af] = simPerWorker(calcLib,calcNet,doAf);
  if doXf, Xf = getXf(net,data); end
  if (xMatrix)
    if isempty(Y), Y = zeros(sum(nn.output_sizes(net)),data.Q); else Y = cell2mat(Y); end
  end
end

if ~isComposite
  if nargout >= 4
    E = gsubtract(data.T,Y);
    if (nargout>4) && (tMatrix)
      if (data.TS==0) || (net.numOutputs == 0)
        E = zeros(sum(nn.output_sizes),Q);
      else
        E = cell2mat(E);
      end
    end
  end
  if nargout >= 5
    perf = feval(net.performFcn,net,data.T,Y,data.EW,net.performParam);
  end
end

%====================================================================

function [Y,Af] = simPerWorker(calcLib,calcNet,doAf)

ws = warning('off','parallel:gpu:kernel:NullPointer');
try
  if doAf
    [Y,Af] = calcLib.y(calcNet);
  else
    Y = calcLib.y(calcNet);
    Af = [];
  end
catch me
  warning(ws); rethrow(me);
end
warning(ws);

%====================================================================

function [data,err] = simData(net,X,Xi,Ai,T,EW)

data = struct;
err = '';

if ~isa(X,'gpuArray')
  [err,net,X,Xi,Ai,T,EW,Q,TS] = simDataCellOfMatrix(net,X,Xi,Ai,T,EW);
  if ~isempty(err), return, end
  data.format = 'CELLofMATRIX';
else
  [err] = simDataCellOfGPUArray(net,X,Xi,Ai,T,EW);
  if isempty(err)
    [err,net,X,Xi,Ai,T,EW,Q,TS] = simDataCellOfGPUArray(net,X,Xi,Ai,T,EW);
    data.format = 'CELLofGPU';
    
  else
    [err2,net,X,Xi,Ai,T,EW,Q,TS] = simDataGPUArray(net,X,Xi,Ai,T,EW);
    if ~isempty(err2), return, end
    err = '';
    data.format = 'NNDATA2GPU';
  end
end

data.X = X;
data.Xi = Xi;
data.Ai = Ai;
data.Q = Q;
data.TS = TS;
data.T = T;
data.EW = EW;


%====================================================================

function [err,net,X,Xi,Ai,T,EW,Q,TS] = simDataCellOfMatrix(net,X,Xi,Ai,T,EW)

err = '';

if ~isempty(X), X = nntype.data('format',X,'Inputs'); end
if ~isempty(Xi), Xi = nntype.data('format',Xi,'Input delay states'); end
if ~isempty(Ai), Ai = nntype.data('format',Ai,'Layer delay states'); end

if ~isempty(X) && (size(X{1},2) > 0)
  Q = size(X{1},2);
elseif ~isempty(Xi) && ~isempty(Xi{1})
  Q = size(Xi{1},2);
elseif ~isempty(Ai) && ~isempty(Ai{1})
  Q = size(Ai{1},2);
else
  Q = 0;
end

if (net.numInputs == 0) && (size(X,1) == 1) && (size(X{1},1)==0)
  TS = size(X,2);
  X = cell(0,TS);
elseif size(X,2) > 0
  TS = size(X,2);
else
  TS = 0;
end

if isempty(X) || (net.numInputs == 0)
  X = cell(net.numInputs,TS);
  for i=1:net.numInputs
    for ts=1:TS
      X{i,ts} = zeros(net.inputs{i}.size,Q);
    end
  end
end
err = nntype.data('check',X);
if ~isempty(err), err = ['Inputs: ' err]; return; end
[Xn,Xq,Xts,Xs] = nnfast.nnsize(X);
if isempty(X), Xq = Q; end
if (Xs == 1) && (net.numInputs ~= 1)
  Nn = zeros(1,net.numInputs);
  for i=1:net.numInputs,Nn(i) = net.inputs{i}.size; end
  if (Xn == sum(Nn))
    X2 = cell(net.numInputs,Xts);
    for ts=1:Xts
      X2(:,ts) = mat2cell(X{1,ts},Nn,Xq);
    end
    X = X2;
    Xn = Nn;
    Xs = net.numInputs;
  end
end
if (Xs ~= net.numInputs)
  err = 'Number of inputs does not match net.numInputs.'; return;
end

if isempty(T)
  targetIndices = find(net.outputConnect);
  T = cell(net.numOutputs,Xts);
  for i=1:net.numOutputs
    ii = targetIndices(i);
    ti = NaN(net.outputs{ii}.size,Xq);
    for j=1:Xts, T{i,j} = ti; end
  end
end
err = nntype.data('check',T);
if ~isempty(err), err = ['Targets: ' err]; return; end
[Tn,Tq,Tts,Ts] = nnfast.nnsize(T);
if ((Ts == 0) || (Tts ==0)) && (Tq == 0)
  Tq = Xq;
end
if (Tq ~= Xq)
  err = 'Inputs and targets have different numbers of samples.'; return
end
if (Tts ~= Xts)
  err = 'Inputs and targets have different numbers of timesteps.'; return
end
if (Ts == 1) && (net.numOutputs ~= 1)
  Nn = zeros(1,net.numOutputs);
  outputInd = find(net.outputConnect);
  for i=1:net.numOutputs,Nn(i) = net.outputs{outputInd(i)}.size; end
  if (Tn == sum(Nn))
    T2 = cell(net.numOutputs,Xts);
    for ts=1:Xts
      T2(:,ts) = mat2cell(T{1,ts},Nn,Tq);
    end
    T = T2;
    Tn = Nn;
    Ts = net.numOutputs;
  end
end
if (Ts ~= net.numOutputs)
  err = 'Number of targets does not match net.numOutputs.'; return;
end

if isempty(Xi)
  Xi = cell(net.numInputs,net.numInputDelays);
  for i=1:net.numInputs
    xi = zeros(net.inputs{i}.size,Xq);
    for j=1:net.numInputDelays, Xi{i,j} = xi; end
  end
end
err = nntype.data('check',Xi);
if ~isempty(err), err = ['Input states: ' err]; return; end
[Xin,Xiq,Xits,Xis] = nnfast.nnsize(Xi);
if ((Xis == 0) || (Xits ==0)) && (Xiq == 0)
  Xiq = Xq;
end
if (Xiq ~= Xq)
  err = 'Inputs and input states have different numbers of samples.'; return
end
if (Xis ~= net.numInputs)
  err = 'Number of input states does not match net.numInputs.'; return;
end
if (Xits ~= net.numInputDelays)
  err = 'Number of input state timesteps does not match net.numInputDelays.'; return
end
if (Xis > 0) && (Xits > 0)
  for i=1:Xis
    if Xin(i) ~= net.inputs{i}.size
      err = 'Input state sizes does not match net.inputs{:}.size.'; return;
    end
  end
end

if isempty(Ai)
  Ai = cell(net.numLayers,net.numLayerDelays);
  for i=1:net.numLayers
    ai = zeros(net.layers{i}.size,Xq);
    for j=1:net.numLayerDelays, Ai{i,j} = ai; end
  end
end
err = nntype.data('check',Ai);
if ~isempty(err), err = ['Layer states: ' err]; return; end
[Ain,Aiq,Aits,Ais] = nnfast.nnsize(Ai);
if ((Ais == 0) || (Aits ==0)) && (Aiq == 0)
  Aiq = Xq;
end
if (Aiq ~= Xq)
  err = 'Inputs and layer states have different numbers of samples.'; return
end
if (Ais ~= net.numLayers)
  err = 'Number of layers states does not match net.numLayers.'; return;
end
if (Aits ~= net.numLayerDelays)
  err = 'Number of layer state timesteps does not match net.numLayerDelays.'; return
end

%====================================================================

function [err,net,X,Xi,Ai,T,EW,Q,TS] = simDataCellOfGPUArray(net,X,Xi,Ai,T,EW)

err = '';
if (net.numInputDelays + net.numLayerDelays) > 0
  err = 'nnet:parallel:gpuArrayDataDynamicNetwork';
  return
end
if (net.numInputs ~= 1) || (net.numOutputs ~= 1)
  err = 'nnet:parallel:gpuArrayDataMultipleIONetwork';
  return
end

if ~isempty(X)
  Q = size(X,2);
else
  Q = 0;
end

TS = 1;

Ni = net.inputs{1}.size;

if isempty(X), X = {gpuArray(nan(Ni,Q))}; end
if isempty(Xi), Xi = cell(1,0); end
if isempty(Ai), Ai = cell(net.numLayers,0); end
if ~iscell(X), X = {X}; end

if any(size(X) ~= [1 TS])
  err = 'Incorrectly sized inputs X.';
  return
end
for i=1:numel(X)
  x = X{i};
  if size(x,1) ~= Ni
    if (Ni == 0)
      err = 'Network must be configured with CONFIGURE before training with gpuArray data.';
    else
      err = 'Incorrectly sized inputs X.';
      return
    end
  end
  if size(x,2) ~= Q
    err = 'Incorrectly sized inputs X.';
    return
  end
end

if ~isempty(Xi)
  err = 'Incorrectly sized input states Xi.';
  return
end

if ~isempty(Ai)
  err = 'Incorrectly sized layer states Ai.';
  return
end

T = {};
EW = {};

%====================================================================

function [err,net,X,Xi,Ai,T,EW,Q,TS] = simDataGPUArray(net,X,Xi,Ai,T,EW)

err = '';

if ~isempty(X)
  precision = class(gather(X(1)));
elseif ~isempty(Xi)
  precision = class(gather(Xi(1)));
elseif ~isempty(Ai)
  precision = class(gather(Ai(1)));
else
  precision = 'double';
end

QQs = [size(X,1) size(Xi,1) size(Ai,1)];
QQs(QQs == 0) = [];
QQ = max([0 QQs]);
if any(QQs ~= QQ)
  err = 'Number of samples (rows of gpuArrays) of data arguments do not match.';
  return
end

if ~isempty(X)
  Qv = X;
elseif ~isempty(Xi)
  Qv = Xi;
elseif ~isempty(Ai)
  Qv = Ai;
else
  Qv = [];
end
realRows = gather(any(isfinite(Qv),2));
Q = find(realRows,1,'last');

Ni = sum(nn.input_sizes(net));
Nl = sum(nn.layer_sizes(net));
NID = net.numInputDelays;
NLD = net.numLayerDelays;
anyInputsZero = any(nn.input_sizes(net)==0);

Ni_TS = size(X,2);
if (Ni_TS == 0)
  TS = 0;
elseif (Ni > 0)
  TS = Ni_TS / Ni;
  if (TS ~= floor(TS))
    if anyInputsZero
      err = 'Input data size  (gpuArray columns) does not match input sizes. Fix data or CONFIGURE network.';
    else
      err = 'Input data size  (gpuArray columns) does not match input sizes.';
    end
    return;
  end
else
  TS = 0;
end


if isempty(X), X = gpuArray(nan(QQ,Ni*TS,precision)); end
if isempty(Xi), Xi = gpuArray(nan(QQ,Ni*NID,precision)); end
if isempty(Ai), Ai = gpuArray(nan(QQ,Nl*NLD,precision)); end

if any(size(X) ~= [QQ Ni*TS])
  if anyInputsZero
    err = 'Input data size  (gpuArray columns) does not match input sizes. Fix data or CONFIGURE network.';
  else
    err = 'Input data size  (gpuArray columns) does not match input sizes.';
  end
  return
end
if any(size(Xi) ~= [QQ Ni*NID])
  err = 'Input state size  (gpuArray columns) does not match input sizes times input delay states.';
end
if any(size(Ai) ~= [QQ Nl*NLD])
  err = 'Layer state size  (gpuArray columns) does not match layers sizes times layer delay states.';
end

T = {};
EW = {};

%====================================================================

function Xf = getXf(net,data)

if ~isempty(data)
  Xf = cell(net.numInputs,net.numInputDelays);
  for ts=1:net.numInputDelays
    x_ts = ts+data.TS-net.numInputDelays;
    if (x_ts) < 1
      xi_ts = x_ts + net.numInputDelays;
      Xf(:,ts) = data.Xi(:,xi_ts);
    else
      Xf(:,ts) = data.X(:,x_ts);
    end
  end
else
  Xf = [];
end

%====================================================================

function [calcLib,calcNet,net,resourceText] = nncalc_setup(calcMode,net,data)

[calcMode,calcNet,calcData,calcHints,net,resourceText] = nncalc.setup1(calcMode,net,data);

if isa(calcMode,'Composite');
  spmd
    [calcLib,calcNet] = nncalc.setup2(calcMode,net,calcData,calcHints);
  end
else
  [calcLib,calcNet] = nncalc.setup2(calcMode,calcNet,calcData,calcHints);
end
