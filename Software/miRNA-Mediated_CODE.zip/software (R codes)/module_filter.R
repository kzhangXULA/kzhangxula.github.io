### refining the the identified module sets by integrating the evidences of miRNA expression retrieved from GSE14794.



library(limma)

dat=read.csv("GSE14794_192_microRNA profiles_no_normalization.txt", header=T, sep="\t")
id=rep(1:192)*4+1
p=dat[,c(1,id)]

library(Biobase)
p.med=rowMedians(as.matrix(p[,2:193]))

p.med=p.adjust(p.med, method="BH")
id=which(p.med<.05)
r.5=dat[id,1]

ceu=read.table("LD_reg_ceu_ext_a.txt", header=T, sep="\t")
m=match(ceu$MiRBase_ID,r.5,nomatch=0)
ix=which(m!=0)
ceu=ceu[ix,]

yri=read.table("LD_reg_yri_ext_a.txt", header=T, sep="\t")
m=match(yri$MiRBase_ID,r.5,nomatch=0)
ix=which(m!=0)
yri=yri[ix,]

gene=read.table("geneList.txt", header=T, sep="\t")
m=match(ceu[,2],gene[,1])
ceu=cbind(gene[m,2],ceu)

m=match(yri[,2],gene[,1])
yri=cbind(gene[m,2],yri)

##################
reg.adj.p.value=p.adjust(ceu$reg.p.value,method="BH")
ceu[,21]=reg.adj.p.value
ix=which(ceu[,19]<0.01&ceu[,20]<0&ceu[,21]<.05)
ceu=ceu[ix,]

reg.adj.p.value=p.adjust(yri$reg.p.value,method="BH")
yri[,21]=reg.adj.p.value
ix=which(yri[,19]<0.01&yri[,20]<0&yri[,21]<.05)
yri=yri[ix,]

write.table(ceu,"manuscript_GSE14794/probset_ceu.txt",col.names=T,row.names=F, sep="\t", quote=F)
write.table(yri,"manuscript_GSE14794/probset_yri.txt",col.names=T,row.names=F, sep="\t", quote=F)











