## Calculating target site effects on gene expression using YRI data 


gt_yri=read.table("arr_genetype_informative_snpListPlus_yri.txt", header=T, sep="\t")
ar_yri=read.table("fraser_matrix_yri.txt",header=T, sep="\t")
st_yri=read.table("structure_yri_a.txt", head=F, sep="\t")

cr_yri=read.table("cr_yri.txt", header=T, sep="\t")
ds_yri=read.table("ds_yri.txt", header=T, sep="\t")


tar=rbind(cr_yri,ds_yri)
n=dim(tar)[1];m=dim(tar)[2]

cr_ds=tar[,11]
p=beta=rep(0,n)

for(i in 1:n){#
  id1=which(as.character(gt_yri[,1])==as.character(tar[i,12]))
  id2=which(as.character(ar_yri[,1])==as.character(tar[i,1]))

  A=paste(tar[i,14],tar[i,14],sep="");B=paste(tar[i,17],tar[i,17],sep="");
  C=paste(tar[i,14],tar[i,17],sep="");D=paste(tar[i,17],tar[i,14],sep="");

  x0=rep(1,89)

  if(length(id1)==1&length(id2)==1){
    y=as.numeric(ar_yri[id2,2:90])
    x=as.factor(as.matrix(gt_yri[id1,8:96]))
    s=as.factor(as.matrix(st_yri[3,2:90]))

    a=which(as.character(x)==A);b=which(as.character(x)==B)
    
    x0[a]=2;x0[b]=0
    if(cr_ds[i]=="cr"){x0[a]=0;x0[b]=2}
 
#   age=as.factor(as.matrix(st_yri[4,2:90]))   
    if(length(table(x))>2){
      md=lm(y~s+x0)
      p[i]=anova(md)[2,5]
      beta[i]=md$coefficients[3]
    }
  } 
} 
 
id=which(p>0)
q=p[id]
sig=tar[id,]
coef=beta[id]

adj.p=p.adjust(q, method="BH")
ix=which(adj.p<0.05)

out=cbind(sig[ix,c(1:2,4,6,11:13,16,19)],coef[ix],adj.p[ix])
#print(out)
#write.table(out, file="result_gene/sigGene_yri.txt", row.names=F, col.names=T, sep="\t", quote=F)










  