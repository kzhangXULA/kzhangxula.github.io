### Integrate the evidences of miRNA expression retrieved from GEO1520, into the results of TSE analysis. 
### The identified modules will be further refined on the the evidences of miRNA expression retrieved from GEO14794


ceu=read.table("LD_reg_ceu_ext.txt", header=T, sep="\t")
mir=read.table("miR_Family_Info.txt",header=T, sep="\t")
mie=read.table("GSE15250_bgExpr_cy3.txt", header=T, sep="\t")

n=dim(ceu)[1]
mire=mir.p=rep("NA",n)
m=dim(mie)[2]
n.syn.mirna=rep(0,n)


for(i in 1:n){
   id=which(as.character(as.matrix(mir[,3]))==as.character(ceu$MiRBase_ID[i]))
   if(length(id)!=0){
     a=mir[id,3]
     b=match(a,mie[,1],nomatch=0)   #print(length(b))

     if(length(which(b>0)!=0)){
       set=mie[b,2:m]
       mire[i]=mean(as.matrix(set),na.rm=T)
       mir.p[i]=t.test(as.vector(as.matrix(set)),na.rm=T)$p.value
     }

   }

  ix=which(ref$Gene==as.character(ceu$Refseq[i])&ref$miRNA==as.character(ceu$miRNA[i]))
  n.syn.mirna[i]=length(ix)
}  
      
out=cbind(ceu,mire,mir.p,n.syn.mirna)
write.table(out, file="LD_reg_ceu_ext_a.txt", col.names=T, row.names=F, sep="\t", quote=F)
        
