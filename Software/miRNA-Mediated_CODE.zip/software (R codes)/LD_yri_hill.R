##Calculating linkage disequilibrium (LD) using Hill's maximum likelihood method: applied to YRI data


hill=function(x,y){

  n11=n22=n12=n21=0
  N=length(which(x>=0&y>=0))
  n11=length(which(x==2&y==2))
  n22=length(which(x==1&y==1))
  n12=length(which(x==2&y==1))
  n21=length(which(x==1&y==2))
  
  pA1=(length(which(x==2&y>=0))*2+length(which(x==1&y>=0)))/(2*N)
  pB1=(length(which(y==2&x>=0))*2+length(which(y==1&x>=0)))/(2*N)

  pu=(2*n11+n12+n21+n22)/(2*N)
  pd=(2*n11+n12+n21)/(2*N)

  p11=pA1*pB1
  for(i in 1:500){
    num=2*n11+n12+n21+n22*p11*(1-pA1-pB1+p11)
    den=2*N*(p11*(1-pA1-pB1+p11)+(pA1-p11)*(pB1-p11))
    p11=num/den+rnorm(1,0,0.001)
    p11=min(p11,pu)
    p11=max(p11,pd)
  }

  D=p11-pA1*pB1
  C=pA1*pB1*(1-pA1)*(1-pB1)
  r2=D^2/C
  #r=sqrt(r2)

  print(c(D,sqrt(C)))

  x2=2*N*r2
  xp=1-pchisq(x2, df= 1)

  list(estimate=r2,p.value=xp)

} 

 
LD=function(a,b,c,d,x,y){

  g1=paste(a,a,sep="")
  g2=paste(b,b,sep="")
  g3=paste(a,b,sep="")
  g4=paste(b,a,sep="")
  ix=which(x==g1);x[ix]=2
  ix=which(x==g2);x[ix]=0
  ix=which(x==g3|x==g4);x[ix]=1
  x=as.numeric(as.matrix(x))

  g1=paste(c,c,sep="")
  g2=paste(d,d,sep="")
  g3=paste(c,d,sep="")
  g4=paste(d,c,sep="")
  ix=which(y==g1);y[ix]=2
  ix=which(y==g2);y[ix]=0
  ix=which(y==g3|y==g4);y[ix]=1
  y=as.numeric(as.matrix(y))

  #r=cor.test(x,y,use="pairwise")
  r=hill(x,y)
  ot=as.vector(c(r$estimate,r$p.value))

  list(OT=ot)
}


#################
fras=read.table("fraser_YRI_edit.txt", header=T, sep="\t")
genet=read.table("arr_genetype_informative_snpListPlus_yri.txt", header=T, sep="\t")
w=dim(genet)[2]

cr_yri=read.table("cr_yri.txt", header=T, sep="\t")
ds_yri=read.table("ds_yri.txt", header=T, sep="\t")
yri=rbind(cr_yri,ds_yri)
cl=c(12,4,6,11,14,17)

hd1=names(fras)
hd2=names(yri)[cl]
headLine=c(hd1,hd2,"LD.cor","LD.p.value")
write.table(t(headLine), file="result_probeset_hill/LD_yri.txt", col.names=F, row.names=F, sep="\t", quote=F, appen=F)

id=which(fras[,4]>2)
fras=fras[id,] 
n=dim(fras)[1]
for(i in 1:n){#print(i)    #n

  gen=fras[i,2];rs=fras[i,3]
  id=which(genet[,1]==as.character(rs))
  a=genet[id,2];b=genet[id,3];x=genet[id,8:w]

  id=which(yri[,1]==as.character(gen));m=length(id)

  if(m!=0){
    set=yri[id,]
    for(j in 1:m){
      rs1=set$snp_id[j]
      id=which(genet[,1]==as.character(rs1))
      c=genet[id,2];d=genet[id,3];y=genet[id,8:w]
      
      r=LD(a,b,c,d,x,y)$OT
      out=c(as.matrix(fras[i,]),as.matrix(set[j,cl]),r)
      write.table(t(out), file="result_probeset_hill/LD_yri.txt", col.names=F, row.names=F, sep="\t",quote=F, appen=T)
    }
  }

}
