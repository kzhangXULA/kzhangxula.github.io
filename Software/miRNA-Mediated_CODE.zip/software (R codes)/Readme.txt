Copyright: Wensheng Zhang and Kun Zhang
If you use the code in this package,
Please cite miRNA-Mediated Relationships between Cis-SNP Genotypes and Transcript Intensities in Lymphocyte Cell Lines". PLoS ONE 7(2): e31429. doi:10.1371/journal.pone.0031429
