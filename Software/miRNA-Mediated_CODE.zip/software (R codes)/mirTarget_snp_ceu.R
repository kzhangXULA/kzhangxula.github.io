## Identifying miRNA target sites against CEU variant sequences



########## filter SNP
rSNP=function(ceu){

  id=which(ceu[,15]>=0.1&ceu[,15]<=0.9) #id=which(m==0&ceu[,15]>=0.1&ceu[,15]<=0.9)
  set=ceu[id, c(1,3,14)]
  
  list(OT=set)

} 


######### recode sequence
mutation=function(sq,b,e,snp){

  id=which(snp[,2]>=b&snp[,2]<=e)
  if(length(id)==0)out=subseq(sq,b,e)
  else{                                      
    dna=s2c(as.character(subseq(sq,b,e)))
    al=snp[id,]

    if(length(id)>1)al=cmp(al)$OT            #Address adjacent SNP
    
    pos=al[,2]-b+1
    dna[pos]=as.character(al[,3]);
    out=DNAString(c2s(dna))                            
  }
  
  list(OT=out)

}

########
cmp=function(al){
  m=dim(al)[1]
  dist=al[2:m,2]-al[1:(m-1),2]
  dist=c(10,dist)
  id=which(dist>9)
  out=al[id,]

  list(OT=out)
}


########## read genome
genome=function(ch){

  if(ch==1)a=Hsapiens$chr1;
  if(ch==2)a=Hsapiens$chr2; 
  if(ch==3)a=Hsapiens$chr3;
  if(ch==4)a=Hsapiens$chr4; 
  if(ch==5)a=Hsapiens$chr5;
  if(ch==6)a=Hsapiens$chr6; 
  if(ch==7)a=Hsapiens$chr7;
  if(ch==8)a=Hsapiens$chr8; 
  if(ch==9)a=Hsapiens$chr9;
  if(ch==10)a=Hsapiens$chr10; 
  if(ch==11)a=Hsapiens$chr11;
  if(ch==12)a=Hsapiens$chr12; 
  if(ch==13)a=Hsapiens$chr13;
  if(ch==14)a=Hsapiens$chr14; 
  if(ch==15)a=Hsapiens$chr15;
  if(ch==16)a=Hsapiens$chr16;
  if(ch==17)a=Hsapiens$chr17;
  if(ch==18)a=Hsapiens$chr18; 
  if(ch==19)a=Hsapiens$chr19;
  if(ch==20)a=Hsapiens$chr20; 
  if(ch==21)a=Hsapiens$chr21;
  if(ch==22)a=Hsapiens$chr22; 
  if(ch=="X")a=Hsapiens$chrX; 
  if(ch=="Y")a=Hsapiens$chrY;
  
  list(OT=a)
}

library(BSgenome)
library(BSgenome.Hsapiens.UCSC.hg18)
library(seqinr)
library(Biostrings)

utr=read.table("con_utr_region_rna/3'UTR_rna.txt", header=T, sep="\t")             #3'UTR-consRegion_rna.txt
mir=read.table("miR_Family_Info_hs_com_rev-545.txt", header=T, sep="\t")
nMir=dim(mir)[1]

di="w_utrTarget"
dir.create(di,showWarnings=FALSE)
outFileName=paste(di,"/","target-7mer-m8_snp_ceu",".txt",sep="")

headLine=t(c("Gene","Chr","Strand","miRNA","7mer-m8","matchType","seedStart_G","seedEnd_G","seedStart_U","seedEnd_U"))
headLine0=headLine
write.table(headLine,file=outFileName,col.names=F,row.names=F,sep="\t",quote=F)

for(i in 6:24){print(paste("chr",i,sep=""))

  cx=i
  if(i==23)cx="X"
  if(i==24)cx="Y"

  fileName=paste("CEU_frq/allele_freqs_chr", cx, "_CEU_r27_nr.b36_fwd.txt", sep="")
  ceu=read.table(fileName,header=T, sep="\t")

  sq=genome(cx)$OT
  snp=rSNP(ceu)$OT

  ch=paste("chr",cx,sep="")
  id=which(utr[,2]==ch)
  nUtr=length(id)
  strUtr=utr[id,3]
  bUtr=utr[id,4]
  eUtr=utr[id,5]
  gUtr=utr[id,1] 

  for(k in 1:nUtr){ print(k)                               #nUtr

    se=mutation(sq,bUtr[k]-1,eUtr[k]+1,snp)$OT; l=nchar(se)
    sUtr=DNAString(subseq(se,2,l-1))
   
    if(strUtr[k]=="-"){
      sUtr=reverseComplement(sUtr)
      se=reverseComplement(se)
    }
    se=as.character(se)   
 

    for(j in 1:nMir){                                      #nMir
      iMir=mir[j,1]
      sMir=mir[j,4]
      m8=as.character(mir[j,2])
      
      seed=substr(m8,2,7);eSeed=substr(m8,1,7);e1=substr(m8,1,1)
      loc=matchPattern(seed, DNAString(sUtr), max.mismatch=0)
      loc=as.data.frame(loc)
      tn=dim(loc)[1]               

      if(tn>0){
        lo=loc
        if(strUtr[k]=="+")loc=loc[,1:2]+ bUtr[k]-1
        else loc=(l-loc[,2:1]+1)+ bUtr[k]-1

        for(s in 1:tn){
          p1=substr(se,lo[s,1],lo[s,1])
          f1=substr(se,lo[s,2]+2,lo[s,2]+2) 

          if(p1==e1&f1!="A"){         
            out=cbind(gUtr[k],ch,strUtr[k],iMir,eSeed,"m8",loc[s,],lo[s,1:2])       #"mer8"
            headLine=rbind(headLine,as.matrix(out))
          }
          else if(p1!=e1&f1=="A"){         
            out=cbind(gUtr[k],ch,strUtr[k],iMir,eSeed,"1a",loc[s,],lo[s,1:2])
            headLine=rbind(headLine,as.matrix(out))
          }
          else if(p1==e1&f1=="A"){         
            out=cbind(gUtr[k],ch,strUtr[k],iMir,eSeed,"8mer",loc[s,],lo[s,1:2])    #"1a-mer8"
            headLine=rbind(headLine,as.matrix(out))
          }
          else{
            out=cbind(gUtr[k],ch,strUtr[k],iMir,eSeed,"6mer",loc[s,],lo[s,1:2])    #"6 mer"
            headLine=rbind(headLine,as.matrix(out))
          }

        }
      }

    }     
  
# }
  
  m=dim(headLine)[1]
  if(m>1)write.table(as.data.frame(headLine[2:m,]), file=outFileName, col.names=F, row.names=F, sep="\t", quote=F, appen=T)
  headLine=headLine0
  }
}
   
 


  