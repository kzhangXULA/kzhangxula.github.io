#### Codes for visualizing the scores of the conservative and SNP-involved miRNA target sites


cr=read.table("crTarget.txt", header=T, sep="\t")
cn=read.table("conTarget.txt", header=T, sep="\t")

par(mfrow=c(2,3))

p1=hist(cr$X3..pairing.contribution,nclass=10, cex.lab=1.2, xlab="3' pairing score", freq=F, main="SNP-involved target sites",xlim=c(-.12,.08))
p2=hist(cr$local.AU.contribution,nclass=10, cex.lab=1.2, xlab="Local AU score", freq=F, main="SNP-involved target sites")
p3=hist(cr$position.contribution,nclass=10, cex.lab=1.2,xlab="Position score", freq=F, main="SNP-involved target sites")

p4=hist(cn$X3pairing_contr,nclass=10,cex.lab=1.2, xlab="3' pairing score", freq=F, main="Conserved target sites",xlim=c(-.12,.08))
p5=hist(cn$local_AU_contr,nclass=10, cex.lab=1.2, xlab="Local AU score", freq=F, main="Conserved target sites")
p6=hist(cn$position_contr,nclass=10, cex.lab=1.2, xlab="Position score", freq=F, main="Conserved target sites")

