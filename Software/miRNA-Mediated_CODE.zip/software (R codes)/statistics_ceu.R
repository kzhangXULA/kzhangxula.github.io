## Calculating target site effects on gene expression using CEU data 


gt_ceu=read.table("arr_genetype_informative_snpListPlus_ceu.txt", header=T, sep="\t")
ar_ceu=read.table("fraser_matrix_ceu.txt",header=T, sep="\t")
st_ceu=read.table("structure_ceu_a.txt", head=F, sep="\t")

#ar_ceu=read.table("GSE7792_series_matrix_gene_mrna_refseq_ceu.txt",header=T, sep="\t")

cr_ceu=read.table("cr_ceu.txt", header=T, sep="\t")
ds_ceu=read.table("ds_ceu.txt", header=T, sep="\t")


tar=rbind(cr_ceu,ds_ceu)
n=dim(tar)[1];m=dim(tar)[2]

cr_ds=tar[,11]
p=beta=rep(0,n)

for(i in 1:n){#n
  id1=which(as.character(gt_ceu[,1])==as.character(tar[i,12]))
  id2=which(as.character(ar_ceu[,1])==as.character(tar[i,1]))

  A=paste(tar[i,14],tar[i,14],sep="");B=paste(tar[i,17],tar[i,17],sep="");
  C=paste(tar[i,14],tar[i,17],sep="");D=paste(tar[i,17],tar[i,14],sep="");

  x0=rep(1,87)

  if(length(id1)==1&length(id2)==1){
    y=as.numeric(ar_ceu[id2,2:88])
    x=as.factor(as.matrix(gt_ceu[id1,8:94]))
    s=as.factor(as.matrix(st_ceu[3,2:88]))

    a=which(as.character(x)==A);b=which(as.character(x)==B)
    
    x0[a]=2;x0[b]=0
    if(cr_ds[i]=="cr"){x0[a]=0;x0[b]=2}
 
#   age=as.factor(as.matrix(st_ceu[4,2:88]))   
    if(length(table(x))>2){
      md=lm(y~s+x0)
      p[i]=anova(md)[2,5]
      beta[i]=md$coefficients[3]
    }
  } 
} 
 
id=which(p>0)
q=p[id]
sig=tar[id,]
coef=beta[id]

adj.p=p.adjust(q, method="BH")
ix=which(adj.p<0.05)

out=cbind(sig[ix,c(1:2,4,6,11:13,16,19)],coef[ix],adj.p[ix])

print(out)










  