### Visualizing miRNA target site effect by boxplots


ls=read.table("result_gene/manuscript/Venn_CEU_YRI.txt", header=T, sep=",")
g_ceu=read.table("arr_genetype_informative_snpListPlus_ceu.txt", header=T, sep="\t")
g_yri=read.table("arr_genetype_informative_snpListPlus_yri.txt", header=T, sep="\t")
e_ceu=read.table("fraser_matrix_ceu.txt", header=T, sep="\t")
e_yri=read.table("fraser_matrix_yri.txt", header=T, sep="\t")

g=2
gn=as.character(ls[g,1])
mr=as.character(ls[g,2])
sn=as.character(ls[g,4])
mirna=as.character(ls[g,3])

a=which(g_yri[,1]==sn)
x=as.matrix(g_yri[a,8:94])

b=which(e_yri[,1]==mr)
y=as.matrix(e_yri[b,2:88])
c=which(x!="")


main=paste("YRI",gn,sn,mirna,sep=", ")
boxplot(y[c]~x[c],col = "lightgray", main=main, xlab="Genotype",ylab="Gene expression")


