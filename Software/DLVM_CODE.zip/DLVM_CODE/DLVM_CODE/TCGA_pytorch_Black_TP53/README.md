Copyright: Zhong Chen and Kun Zhang
If you use the code in this package,
Please cite:[1] Chen, Z., Edwards, A., Hicks, C. and Zhang, K., 2020. Inferring Personalized and Race-Specific Causal Effects of Genomic Aberrations on Gleason Scores: A Deep Latent Variable Model. Frontiers in oncology, 10,

This repository contains a Python3, PyTorch implemenation of the Personalized Causal Effects Inference [1]: Chen, Z., Edwards, A., Hicks, C. and Zhang, K., 2020. Inferring Personalized and Race-Specific Causal Effects of Genomic Aberrations on Gleason Scores: A Deep Latent Variable Model. Frontiers in oncology, 10, p.272.

Run: Python main.py (TP53 mutation in black group as the example)

This code is based on the Autoencoder (CEVAE) model as developed at [2]. The original Python2 TensorFlow (+Edward) implementation can be found here: https://github.com/AMLab-Amsterdam/CEVAE



References
[1] Chen, Z., Edwards, A., Hicks, C. and Zhang, K., 2020. Inferring Personalized and Race-Specific Causal Effects of Genomic Aberrations on Gleason Scores: A Deep Latent Variable Model. Frontiers in oncology, 10, p.272.
[2] Louizos, C., Shalit, U., Mooij, J., Sontag, D., Zemel, R. and Welling, M., 2017. Causal effect inference with deep latent-variable models. arXiv preprint arXiv:1705.08821.

