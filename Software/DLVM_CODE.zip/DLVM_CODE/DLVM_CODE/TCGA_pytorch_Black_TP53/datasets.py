import numpy as np
from sklearn.model_selection import train_test_split

class PCTCGA(object):
    def __init__(self, path_data="datasets/PCTCGA/csv", replications=10):
        self.path_data = path_data
        self.replications = replications
        self.binfeats = [44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90]
        self.contfeats = [i for i in range(91) if i not in self.binfeats]

    def __iter__(self):
        for i in range(self.replications):
            data = np.loadtxt(self.path_data + '/Prostate_Cancer_' + str(i + 1) + '.csv', delimiter=',')
            t, y= data[:, 0], data[:, 1][:, np.newaxis]
            x = data[:, 2][:, np.newaxis]
            yield (x, t, y)

    def get_train_valid_test(self):
        for i in range(self.replications):
            data = np.loadtxt(self.path_data + '/Prostate_Cancer_' + str(i + 1) + '.csv', delimiter=',')
            t, y= data[:, 0][:, np.newaxis], data[:, 1][:, np.newaxis]
            x = data[:, 2:]
            idxtrain, ite = train_test_split(np.arange(x.shape[0]), test_size=0.1, random_state=1)
            itr, iva = train_test_split(idxtrain, test_size=0.3, random_state=1)
            train = (x[itr], t[itr], y[itr])
            valid = (x[iva], t[iva], y[iva])
            test = (x[ite], t[ite], y[ite])
            yield train, valid, test, self.contfeats, self.binfeats
